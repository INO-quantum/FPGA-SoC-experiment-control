#!/usr/local/bin/python3

import matplotlib as mpl
import matplotlib.pyplot as plt
import matplotlib.cm as cm
import numpy as np
import re
from datetime import datetime
import io
import math
from os import listdir
import glob

filepath_ch1 = 'CYCLING_START_STOP/ch1/'
filepath_ch2 = 'CYCLING_START_STOP/ch2/'
filepath_ch1_free = 'CYCLING_FREE/ch1/'
filepath_ch2_free = 'CYCLING_FREE/ch2/'

filename_ch1 = glob.glob(filepath_ch1+'*.CSV')
filename_ch2 = glob.glob(filepath_ch2+'*.CSV')
filename_ch1_free = glob.glob(filepath_ch1_free+'*.CSV')
filename_ch2_free = glob.glob(filepath_ch2_free+'*.CSV')

xylabel_size    = 16 # axis x and y label fontsize
tick_labelsize  = 12 # size of tick labels
text_size       = 12 # size of all text
legend_fontsize = 16 # size of legend text
panel_fontsize  = 16 # size of panel 'a','b' text

def get_float(txt):
    try:
        return float(txt)
    except Exception as e:
        if (len(txt) > 0): print('note: could not parse',txt,'as float')
        return np.NaN

# returns mask which is True where both x and y are not NaN
# apply mask as x[mask] and y[mask]
def mask_pair(x,y):
    return np.logical_and(~np.ma.getmask(np.ma.masked_invalid(x)), ~np.ma.getmask(np.ma.masked_invalid(y)))    
    
def read(filename, scaling=[1.0,1.0]):
    "reads data from CSV file and returns [x,y] data"
    with io.open(filename, 'rt', encoding='latin1') as file:
        x, y = np.loadtxt(file, unpack=True, delimiter=',', skiprows=0, usecols=(3,4), converters={3:get_float, 4:get_float})
        x = x * scaling[0]
        y = y * scaling[1]
        mask = mask_pair(x,y)
        return [x[mask],y[mask]]
    return [[],[]]

def plot(ch1, ch2, label = ['channel 1','channel 2'], ax=None, panel='a'):
    colors = cm.get_cmap('tab20')

    if ax == None: 
        fig = plt.figure(figsize=(7,7*3/4)) #size in inches
        ax = fig.add_axes([0.15, 0.1, 0.8, 0.8])

    ax.xaxis.set_tick_params(which='major',size=10,width=2,direction='in',top='on',labelsize=tick_labelsize)
    ax.xaxis.set_tick_params(which='minor',size=7,width=2,direction='in',top='on',labelsize=tick_labelsize)
    ax.yaxis.set_tick_params(which='major',size=10,width=2,direction='in',right='on',labelsize=tick_labelsize)
    ax.yaxis.set_tick_params(which='minor',size=7,width=2,direction='in',right='on',labelsize=tick_labelsize)

    ax.set_ylim(-6.5, 6.5)

    ax.yaxis.set_major_locator(mpl.ticker.MultipleLocator(5))
    ax.yaxis.set_minor_locator(mpl.ticker.MultipleLocator(2.5))

    ax.set_ylabel(r'signal (V)', labelpad=5, fontsize=xylabel_size)

    label_ch1 = label[0]
    if (len(ch1) > 1) and (label_ch1 != None): label_ch1 = '%s (%d)' % (label_ch1,len(ch1));
    label_ch2 = label[1]
    if (len(ch2) > 1) and (label_ch2 != None): label_ch2 = '%s (%d)' % (label_ch2,len(ch2))
    for i,d in enumerate(ch1):
        if i == 0: ax.plot(d[0], d[1], color=colors(0), label=label_ch1, linestyle='solid')
        else:      ax.plot(d[0], d[1], color=colors(0), linestyle='solid', alpha=np.exp(-i/2.0))
    for i,d in enumerate(ch2):
        if i == 0: ax.plot(d[0], d[1], color=colors(2), label=label_ch2, linestyle='solid')
        else:      ax.plot(d[0], d[1], color=colors(2), linestyle='solid', alpha=1.0)

    t0 = -0.0676
    dt = 0.4
    gap = 0.058
    if panel == 'b':
        times = [0.0, dt+gap, 2*dt+3*gap]
    else:
        times = np.array(range(3))*dt
    for t in times:
        ax.axvline(x=t0+t, color='k', linestyle='dotted')

    if panel == 'b':
        ax.legend(bbox_to_anchor=(0.92, 0.15), loc='lower right', frameon=True, fontsize=10, ncol=1, framealpha=1.0, edgecolor='black')

    #plt.savefig('start_stop.png', dpi=300, transparent=False, bbox_inches='tight')

def panel(ch1_a, ch2_a, ch1_b, ch2_b, label = ['channel 1','channel 2']):

    fig = plt.figure(figsize=(7,7*3/4)) #size in inches

    ax1 = fig.add_axes([0.1, 0.50, 0.88, 0.4])
    plot(ch1_a,ch2_a,label,ax1,'a')
    ax1.xaxis.set_ticklabels([])
    plt.text(0.01,0.90,'a',transform=fig.transFigure,verticalalignment='top', fontsize=panel_fontsize)
    
    ax2 = fig.add_axes([0.1, 0.1, 0.88, 0.4])
    plot(ch1_b,ch2_b,label,ax2,'b')
    plt.text(0.01,0.5,'b',transform=fig.transFigure,verticalalignment='top', fontsize=panel_fontsize)
    ax2.set_xlabel('time (s)', labelpad=5, fontsize=xylabel_size)

    plt.savefig('figure_10.pdf', dpi=300, transparent=False, bbox_inches='tight')
    plt.savefig('figure_10.eps', dpi=300, transparent=False, bbox_inches='tight')


print('channel 1: %d files' %(len(filename_ch1)))
print('channel 2: %d files' %(len(filename_ch2)))
ch1 = [read(name,[1.0,5.0/6.0]) for name in filename_ch1]
ch2 = [read(name) for name in filename_ch2]

#free running
print('channel 1: %d files' %(len(filename_ch1_free)))
print('channel 2: %d files' %(len(filename_ch2_free)))
ch1_free = [read(name,[1.0,5.0/6.0]) for name in filename_ch1_free]
ch2_free = [read(name) for name in filename_ch2_free]

mpl.rcParams['font.family'] = 'DejaVu Sans'
plt.rcParams['font.size'] = 10
plt.rcParams['axes.linewidth'] = 2

panel(ch1_free, ch2_free, ch1, ch2, ['trigger','ramp'])

plt.show()

