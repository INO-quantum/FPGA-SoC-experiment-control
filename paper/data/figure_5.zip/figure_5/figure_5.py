#!/usr/local/bin/python3

import matplotlib as mpl
import matplotlib.pyplot as plt
import matplotlib.cm as cm
from matplotlib.ticker import LogLocator
#from matplotlib.patches import Rectangle
import numpy as np
import re
from datetime import datetime
import io
import math
from os import listdir
from os.path import isfile, join
import glob
from scipy.optimize import curve_fit, minimize
import sys

#useful unicode symbols
Delta = '\u0394'
delta = '\u03b4'
fi    = '\u03c6'
chi   = '\u03c7'
pm    = '\u00b1'

mpl.rcParams['font.family'] = 'DejaVu Sans'
plt.rcParams['font.size'] = 10
plt.rcParams['axes.linewidth'] = 2

#try to have a larger math text but does not work! 
#mpl.rcParams['mathtext.default']='regular'
#mpl.rcParams['mathtext.fontset']='dejavusans'

#import matplotlib.font_manager as fm# Collect all the font names available to matplotlib
#font_names = [f.name for f in fm.fontManager.ttflist]
#print(font_names)

colors = cm.get_cmap('tab20')
#colors = cm.get_cmap('tab20c')
#col=[colors(13),colors(0),colors(9),colors(5)]
#col=[colors(0),colors(4),colors(8)]

def get_float(txt):
    try:
        return float(txt)
    except Exception as e:
        if (len(txt) > 0): print('note: could not parse',txt,'as float')
        return np.NaN

def get_int(txt):
    try:
        return int(txt)
    except Exception as e:
        if (len(txt) > 0): print('note: could not parse',txt,'as integer')
        return np.NaN

def is_float(txt):
    """tests if txt can be converted into float (returns True) or not (returns False)"""
    try:
        y = float(txt)
        return True
    except ValueError:
        return False

# returns mask which is True where both x and y are not NaN
# apply mask as x[mask] and y[mask]
def mask_pair(x,y):
    return np.logical_and(~np.ma.getmask(np.ma.masked_invalid(x)), ~np.ma.getmask(np.ma.masked_invalid(y)))    
def mask_triple(x,y,err):
    return np.logical_and(~np.ma.getmask(np.ma.masked_invalid(x)), ~np.ma.getmask(np.ma.masked_invalid(y)), ~np.ma.getmask(np.ma.masked_invalid(err)))    
    
#returns string in the form value(error)
def str_error(value, error):
    try:
        pwr = np.log10(abs(error))
        #print(pwr)
        pwr = int(math.floor(pwr))
        #print(pwr)
        if pwr < 0: # pwr = digits after comma
            pwr = -pwr
            fmt = '%%.%if(%%i)' % (pwr)
            #print(fmt)
            txt = fmt % (round(value,pwr),int(round(abs(error)*10**pwr)))
        else: # pwr = digits before comma
            fmt = '%i(%i)'
            txt = fmt % (int(round(value/10**pwr))*10**pwr,int(round(abs(error)/10**pwr))*10**pwr)
        print('\t\tstr_error note: %f +/- %f = %s' % (value,error,txt))
        #print(txt)
    except:
        txt = "%f+/-%f" % (value,error);
    return txt

def read(filename, cols=(0,1), scaling=[1,1], skip=0):
    "reads data from CSV file and returns [x,y,..] data"
    cnv={0:get_float, 1:get_float, 2:get_float, 3:get_float, 4:get_float, 5:get_float}
    with io.open(filename, 'rt', encoding='latin1') as file:
        data = np.loadtxt(file, unpack=True, delimiter=',', skiprows=skip, usecols=cols, converters=cnv)
        data = [data[i]*sc for i,sc in enumerate(scaling)]
        return data
    return [[] for _ in cols]

def average(data):
    """
    calculates mean and standard deviation 
    data = [x,y]
    returns list of [x,mean_y,std_y] for each datapoint
    """
    data=np.array(data) # otherwise get sometimes not recognizable error although everything seems correct???
    x,indices = np.unique(data[0],return_inverse=True)
    return np.array([[xi,np.mean(data[1][indices==k]),np.std(data[1][indices==k])] for k,xi in enumerate(x)])

def plot(ax, panel, data, label, model, shade, scale, col, d_args, m_args):
    """
    generic plot of data for all panels
    data = list of data_i per channel with data_i = [data_x,data_y,data_error] with each entry 1d vectors, [] if not used
    label = 1d list of labels for each channel
    model = list of model_i curves for each channel with model_i = [model_x,model_y] with each entry 1d vector, model_i = None if not used
    shade = list of [shade_min_i,shade_max_i] for each channel where shade is drawn between min and max curves consisting of [x,y] with 1d vectors, [] if not used
    scale = 1d list of y-scaling factors for data_y and data_error, 1 = no scaling
    col = 1d list of colors for each channel
    d_args = 1d list of {arguments} for data plot
    m_args = 1d list of {arguments} for model plot
    """
    global c10_rate_10M, c07s_rate_10M
    if ax == None: 
        fig = plt.figure(figsize=(7,7*3/4)) #size in inches
        ax = fig.add_axes([0.1, 0.1, 0.8, 0.8])
        is_panel = False
    else:
        is_panel = True
    #ax.set_title(r'sender + 10m + receiver + 10m + T open/50$\Omega$/short + 10m + 50$\Omega$')

    xylabel_size    = 16 # axis x and y label fontsize
    tick_labelsize  = 12 # size of tick labels
    text_size       = 12 # size of all text
    legend_fontsize = 12 # size of legend text

    ax.xaxis.set_tick_params(which='major', size=10, width=2, direction='in', top='on'  , labelsize=tick_labelsize)
    ax.xaxis.set_tick_params(which='minor', size=7 , width=2, direction='in', top='on'  , labelsize=tick_labelsize)
    ax.yaxis.set_tick_params(which='major', size=10, width=2, direction='in', right='on', labelsize=tick_labelsize)
    ax.yaxis.set_tick_params(which='minor', size=7 , width=2, direction='in', right='on', labelsize=tick_labelsize)

    if panel == 'upload':
        #if not is_panel: ax.set_title('uploading & write data rate')
        ax.set_xscale('log')
        ax.set_xlim(1, 2e7)
        ax.set_ylim(-10,135)
        ax.set_yticks([0,40,80,120])
        ax.set_ylabel(r'$\Gamma$ (MB/s)', labelpad=5.5, fontsize=xylabel_size)
        #ax.set_xticks([10,15,20,25,30])
        if is_panel: 
            ax.set_xticklabels(['']*8)
        else:
            ax.set_xlabel('samples', labelpad=2, fontsize=xylabel_size)
        #Ethernet theoretical limit
        pos = 118.7
        ax.axhline(y=pos, color='k', linestyle='dotted')
        ax.text(1.1e7, 0.97*pos, str(pos)+' MB/s', fontsize=text_size, rotation=0, ha='right', va='top', color='k')
        # server receive buffer size
        pos=512*1024/beta
        ax.axvline(x=pos, color='k', linestyle='dotted')
        ax.text(pos, 0, 'recv. buffer', fontsize=text_size, rotation=90, ha='right', va='bottom')

        #uploading + write rate N=10M Cora-Z7-10/07S boards
        rate = [[1.1e7,69,'%sMB/s'%str_error(c10_rate_10M[0],c10_rate_10M[1])],[1.2e7,32,'%sMB/s'%str_error(c07s_rate_10M[0],c07s_rate_10M[1])]]
        for i,r in enumerate(rate):
            ax.text(r[0], r[1], r[2], fontsize=legend_fontsize, rotation=0, ha='right', va='bottom', color=col[2+i])
    elif panel == 'time':
        #if not is_panel: ax.set_title('uploading & write data rate')
        if True: # log-log
            ax.set_xscale('log')
            ax.set_yscale('log')
            ax.set_xlim(1, 2e7)
            #ax.set_xticks([0,2,4,6,8,10])
            ax.set_ylim(4e-6,40)
            ax.set_yticks([1e-4,1e-2,1])
            #ax.set_yticklabels([r'100$\mu$s','1s'])
            #ax.yaxis.set_minor_locator(LogLocator(base=10,numticks=5))
        else: # linear
            ax.set_xlim(-0.5, 11)
            ax.set_xticks([0,2,4,6,8,10])
            ax.set_ylim(-0.5,3.5)
            ax.set_yticks([0,1,2,3])
        ax.set_ylabel('time (s)', labelpad=0, fontsize=xylabel_size)
        ax.set_xlabel(r'samples', labelpad=1, fontsize=xylabel_size)
        # maximum upload & write time Cora-Z7-07S
        i = 3
        x1 = data[i][0][-1]
        y1 = data[i][1][-1]
        x0 = 8e5
        y0 = y1
        ax.text(x0 - 0.2e5, y0 - 0.1, label[i]+'s', fontsize=legend_fontsize, rotation=0, ha='right', va='center', color=col[i]) #, backgroundcolor='#ffffff')
        ax.plot([x0,x1], [y0,y1], linewidth=1, color=col[i])
        # maximum upload & write time Cora-Z7-10
        i = 2
        x1 = data[i][0][-1]
        y1 = data[i][1][-1]
        x0 = 5e6
        y0 = 1e-2
        ax.text(x0, y0-0.2e-2, label[i]+'s', fontsize=legend_fontsize, rotation=0, ha='center', va='top', color=col[i])
        ax.plot([x0,x1], [y0,y1], linewidth=1, color=col[i])

    a = [None for _ in data]
    for i,d in enumerate(data):
        #shaded region between two curves
        if (len(shade[i]) > 0):
            x = shade[i][0]
            y0 = scale[i]*shade[i][1]
            y1 = scale[i]*shade[i][2]
            #ax.plot(x, y0, color=col[6], linestyle='solid', linewidth=2)
            #ax.plot(x, y1, color=col[7], linestyle='solid', linewidth=2)
            if False: # add transparency: 0 = fully transparent, ff = opaque
                col_rgb=mpl.colors.to_hex(col[i])+"50"
            else: # mimic transparency with solid color (otherwise eps look strange)
                col_rgb=mpl.colors.to_rgba(col[i]) # get color values
                col_rgb = np.array(col_rgb)
                alpha = 0.33
                bg = np.array([1.0,1.0,1.0,1.0])
                col_rgb = col_rgb*alpha+(1-alpha)*bg
                col_rgb[3] = 1.0
            ax.fill_between(x, y0, y1, facecolor=col_rgb, interpolate=False) #'paleturquoise'
        #model curve
        if len(model[i]) != 0: #plot model if not None
            if (len(d) == 0):
                ax.plot(model[i][0], scale[i]*model[i][1], color=col[i], label=label[i], zorder=1, **m_args[i])
            else:
                ax.plot(model[i][0], scale[i]*model[i][1], color=col[i], zorder=1, **m_args[i])
        if (len(d) > 0):
            if len(d) == 2: # get mean and std
                xy = np.transpose(average(d))
                print("note: get mean and std")
            else: # data already contains mean and std
                xy = d
            if scale[i] != 1: 
                print('*** ATTENTION: %s scaled x %i ***' % (label[i],scale[i]))
                xy[1] = xy[1]*scale[i]
                xy[2] = xy[2]*scale[i]
                y=np.array(sorted(xy[1], key=lambda x: x[0]))
                ax.text(y[-1][0], y[-1][1]+30, "x"+str(scale[i]), fontsize=legend_fontsize, rotation=0, ha='right', va='bottom', color=col[i])
            # plot error bars with scaling = sc
            sc = 1
            if len(xy) == 3: # y-error bar
                for j in range(len(xy[0])):
                    ax.plot([xy[0][j],xy[0][j]], [xy[1][j]-sc*xy[2][j],xy[1][j]+sc*xy[2][j]], color=col[i], linestyle='solid', linewidth=2, zorder=1)
            else: # xy-error bar
                for j in range(len(xy[0])):
                    ax.plot([xy[0][j],xy[0][j]], [xy[1][j]-sc*xy[3][j],xy[1][j]+sc*xy[3][j]], color=col[i], linestyle='solid', linewidth=2, zorder=1)
                    ax.plot([xy[0][j]-sc*xy[2][j],xy[0][j]+sc*xy[2][j]], [xy[1][j],xy[1][j]], color=col[i], linestyle='solid', linewidth=2, zorder=1)
            # plot mean values
            a[i] = ax.scatter(xy[0], xy[1], color=col[i], label=label[i], zorder=2, **d_args[i])

    if panel == 'upload':
        # create two legends with titles to make it clearer and shorter length
        l1=ax.legend(handles=a[2:], labels=label[2:], bbox_to_anchor=(0.03, 0.68, 0.34, 0.2), mode='expand', loc='upper left', frameon=True, fontsize=legend_fontsize, ncol=1, framealpha=1.0, edgecolor='black', title="upload & write")
        plt.setp(l1.get_title(),fontsize=legend_fontsize) #title_fontsize does not work, but this works!

        l2=ax.legend(handles=a[:2], labels=label[:2], bbox_to_anchor=(0.03, 0.37, 0.34, 0.2), mode='expand', loc='upper left', frameon=True, fontsize=legend_fontsize, ncol=1, framealpha=1.0, edgecolor='black', title="upload only")
        plt.setp(l2.get_title(),fontsize=legend_fontsize) #title_fontsize does not work, but this works!
        ax.add_artist(l1)

    if not is_panel:
        plt.savefig('figure_'+panel+'.pdf', dpi=300, transparent=False, bbox_inches='tight')

def panel(data, label, model, shade, scale, col, d_args, m_args):

    fig = plt.figure(figsize=(7,7*3/4)) #size in inches

    #panels from top to bottom
    panels = ['upload','time']
    labels = ['a','b']
    height = [0.55,0.35]
    gap    = [0.0,0.09]
    left = 0.1
    width = 0.9

    ax = [None for p in panels]
    for i,p in enumerate(panels):
        y_top = sum(gap[i:]) + sum(height[i:]) # y top coordinate of panel
        ax[i] = fig.add_axes([left, y_top-height[i], width, height[i]])
        plot(ax[i], p, data[i], label[i], model[i], shade[i], scale[i], col[i], d_args[i], m_args[i])
        if labels[i] is not None: plt.text(0.01,y_top,labels[i],fontsize=16,transform=fig.transFigure,verticalalignment='top')

    #ax[0].set_title(r'sender + 10m + receiver high Z + 10m + 50$\Omega$/open/short')

    plt.savefig('figure_5.pdf', dpi=300, transparent=False, bbox_inches='tight')
    plt.savefig('figure_5.eps', dpi=300, transparent=False, bbox_inches='tight')

def delay_model(N, delay, rate):
    'return rate in MB/s for given delay (cycles) and data rate (MB/s) for N = number of samples'
    global f_PL, beta
    return f_PL*beta*N/(abs(delay) + f_PL*beta*N/rate)

def fit_delay(x, y, dy=None, p0 = [10,50]):
    """
    fit rate y(x) with delay and rate model.
    if dy is not None uses y-errors
    returns [par,err] with par = [delay,rate] and err = [delay_error,rate_error].
    """
    global f_PL, beta
    chi2_start = np.sum(np.power(delay_model(x, p0[0], p0[1])-y,2))
    par, cov = curve_fit((lambda x,d,r: delay_model(x, d, r)), x, y, p0 = p0, sigma=dy, absolute_sigma=False)     
    err = np.sqrt(np.diag(cov))
    chi2_fit = np.sum(np.power(delay_model(x, par[0], par[1])-y,2))
    if True:    
        print('start chi^2 = ',chi2_start)
        print('fit chi^2 = ',chi2_fit)
        print('delay %s cycles = %s us, rate %s MB/s' % (str_error(abs(par[0]),err[0]),str_error(abs(par[0])/f_PL,err[0]/f_PL),str_error(par[1],err[1])))
    return [par,err]

##########################################################################################################
# globals
##########################################################################################################

f_PL = 50       # PL cycle frequency
beta = 12       # bytes per sample

#x-values for model plots
xfit = np.array([2**i for i in np.arange(1,23,0.1)] + [1.1e7]) # samples in powers of 2

##########################################################################################################
# load data
##########################################################################################################

# all data contain [N,N_first,t_RT,t_upload,t_tot,ticks,CPU0 in %, CPU1 in %]
# N = total number of samples
# N_first = bytes in first buffer
# t_RT     = time in cycles from ACK of server to write until arrival of first data (N_first)
# t_upload = time in cycles from ACK of server to write until N data uploaded
# t_tot    = time in cycles from ACK of server to write until N data uploaded and saved to DMA memory
# ticks    = CPU ticks in us for approximately same time span as t_tot
# CPU0 = % of CPU 0 usage 100000 = 100% measured after upload & write finished*
# CPU1 = % of CPU 1 usage 100000 = 100% measured after upload & write finished*
# *started at ACK of server but not sure if this is average over everything or just last measurement

# Cora-C7-10 upload & write
if False: # fit all data
    folders = ['20210425_upload/data_3','20210425_upload/data_4','20210425_upload/data_2','20210425_upload/data_5','20210426_upload/data_1','20210426_upload/data_2']
    names = ['Cora-Z7-10 parallel','Cora-Z7-10 sequential','Cora-Z7-07S parallel','Cora-Z7-07S sequential','Cora-Z7-10 immedidate','Cora-Z7-07S immedidate']
else: # fit only data for paper
    folders = ['20210425_upload/data_3','20210425_upload/data_4',None,'20210425_upload/data_5',None,'20210426_upload/data_2']
    names = ['Cora-Z7-10 parallel','Cora-Z7-10 sequential',None,'Cora-Z7-07S sequential',None,'Cora-Z7-07S immedidate']
data         = [[] for _ in folders]
time_upload  = [[] for _ in folders]
time_tot     = [[] for _ in folders]
tmax_u       = [[] for _ in folders]
tmax_t       = [[] for _ in folders]
rate_upload  = [[] for _ in folders]
rate_tot     = [[] for _ in folders] 
model_upload = [[] for _ in folders]
model_tot    = [[] for _ in folders]
model_tupload= [[] for _ in folders]
model_ttot   = [[] for _ in folders]
par_tot      = [[] for _ in folders]
err_tot      = [[] for _ in folders]
for i,f in enumerate(folders):
    if f is not None:
        name   = 'result.csv'
        data[i] = np.array(read(f+'/'+name,(0,1,2,3,4,5,6,7),[1,1,1/50,1/50,1/50,1,1e-3,1e-3],skip=0))
        N = np.unique(data[i][0])
        N = N[~np.isnan(N)]
        Nmax = N[-1]
        t_RT         = np.array([np.mean(data[i][2][data[i][0]==Ni]) for Ni in N])
        t_RT_err     = np.array([np.std (data[i][2][data[i][0]==Ni]) for Ni in N])
        t_upload     = np.array([np.mean(data[i][3][data[i][0]==Ni]) for Ni in N])
        t_upload_err = np.array([np.std (data[i][3][data[i][0]==Ni]) for Ni in N])
        t_tot        = np.array([np.mean(data[i][4][data[i][0]==Ni]) for Ni in N])
        t_tot_err    = np.array([np.std (data[i][4][data[i][0]==Ni]) for Ni in N])

        # error uploading (t_upload-t_RT/2), and total time (t_tot-t_RT/2)
        t_err_upload = np.sqrt((t_RT_err/2)**2+t_upload_err**2)
        t_err_tot    = np.sqrt((t_RT_err/2)**2+t_upload_err**2)

        # upload only and total rate in MB/s [N,rate,error]
        rate_upload[i] = [N,N*beta/(t_upload-t_RT/2),t_err_upload*N*beta/(t_upload-t_RT/2)**2]
        rate_tot[i]    = [N,N*beta/(t_tot   -t_RT/2),t_err_tot   *N*beta/(t_tot   -t_RT/2)**2]

        # upload + write time without acknowledge time (t_RT/2)
        time_upload[i] = [N, (t_upload-t_RT/2)*1e-6, 1e-6*np.sqrt(t_upload_err**2 + (t_RT_err/2)**2)]
        time_tot[i]    = [N, (t_tot-t_RT/2)*1e-6, 1e-6*np.sqrt(t_tot_err**2 + (t_RT_err/2)**2)]

        # fit delay upload
        tmax = (t_upload-t_RT/2)[-1]/1e6
        tmax_err = t_err_upload[-1]/1e6
        tmax_u[i] = str_error(tmax,tmax_err)
        trte = str_error(np.mean(t_RT)/1e3,np.max([np.std(t_RT),np.mean(t_RT_err)])/1e6)
        print('\n%ia: fit %s upload only:\nN_max %i, t_max = %s s, t_RT = %s ms' % (i, names[i], Nmax, tmax_u[i], trte))
        [par, err] = fit_delay(x=N, y=rate_upload[i][1], dy=rate_upload[i][2], p0 = [20000,50])
        model_upload[i]  = [xfit, delay_model(xfit,par[0],par[1])]
        model_tupload[i] = [xfit,par[0]*1e-6/50+xfit*beta*1e-6/par[1]]

        # fit delay upload & write
        tmax = (t_tot-t_RT/2)[-1]/1e6
        tmax_err = t_err_tot[-1]/1e6
        tmax_t[i] = str_error(tmax,tmax_err)
        trte = str_error(np.mean(t_RT)/1e3,np.max([np.std(t_RT),np.mean(t_RT_err)])/1e3)
        print('\n%ib: fit %s upload & write:\nN_max %i, t_max = %s s, t_RT = %s ms' % (i, names[i], Nmax, tmax_t[i], trte))
        [par, err] = fit_delay(x=N, y=rate_tot[i][1], dy=rate_tot[i][2], p0 = [20000,50])
        model_tot[i] = [xfit, delay_model(xfit,par[0],par[1])]
        model_ttot[i] = [xfit,par[0]*1e-6/50+xfit*beta*1e-6/par[1]]
        par_tot[i] = par
        err_tot[i] = err

##########################################################################################################
# figure upload & write
##########################################################################################################

# plot total rates
# we take best values for both boards:
# Cora-Z7-10  upload & write: parallel  (#0b), upload: sequential (#1a)
# Coar-Z7-07S upload & write: immediate (#5b), upload: sequential (#3a)
c10_rate_10M  = [par_tot[0][1],err_tot[0][1]]
c07s_rate_10M = [par_tot[5][1],err_tot[5][1]] 
label_a = ['Cora-Z7-10','Cora-Z7-07S','Cora-Z7-10','Cora-Z7-07S']
points_a = [rate_upload[1],rate_upload[3],rate_tot[0],rate_tot[5]]
#line_a = [model_upload[1],model_upload[3],model_tot[0],model_tot[5]]
line_a = [[],[],model_tot[0],model_tot[5]]
shade_a = [[]]*4
scale_a = [1]*4
col_a   = [colors(1),colors(3),colors(0),colors(2),colors(4),colors(6),colors(8),colors(10)]
d_args_a = [{'s':60,'marker':'o','facecolors':'white'},{'s':50,'marker':'s','facecolors':'white'},{'s':60,'marker':'o'},{'s':50,'marker':'s'}]
m_args_a = [{'linestyle':'dotted', 'linewidth':2}]*4

#plot(None, 'upload', points_a, label_a, line_a, shade_a, scale_a, col_a, d_args_a, m_args_a)

#label_b = ['Cora-Z7-10','Cora-Z7-07S','Cora-Z7-10','Cora-Z7-07S']
label_b = [tmax_u[1],tmax_u[3],tmax_t[0],tmax_t[5]]
points_b = [time_upload[1],time_upload[3],time_tot[0],time_tot[5]]
line_b = [[],[],model_ttot[0],model_ttot[5]]
shade_b = [[]]*4
scale_b = [1]*4
col_b   = [colors(1),colors(3),colors(0),colors(2),colors(4),colors(6),colors(8),colors(10)]
d_args_b = [{'s':60,'marker':'o','facecolors':'white'},{'s':50,'marker':'s','facecolors':'white'},{'s':60,'marker':'o'},{'s':50,'marker':'s'}]
m_args_b = [{'linestyle':'dotted', 'linewidth':2}]*4

#plot(None, 'time', points_b, label_b, line_b, shade_b, scale_b, col_b, d_args_b, m_args_b)

panel([points_a,points_b], 
    [label_a,label_b], 
    [line_a,line_b], 
    [shade_a,shade_b], 
    [scale_a,scale_b], 
    [col_a,col_b], 
    [d_args_a, d_args_b], 
    [m_args_a, m_args_b])

plt.show()
