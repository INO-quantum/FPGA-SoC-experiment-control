#!/usr/local/bin/python3

import matplotlib as mpl
import matplotlib.pyplot as plt
import matplotlib.cm as cm
#from matplotlib.patches import Rectangle
import numpy as np
import re
from datetime import datetime
import io
import math
from os import listdir
from os.path import isfile, join
import glob
from scipy.optimize import curve_fit, minimize, differential_evolution
import sys
from scipy.version import version as sc_version
from numpy.version import version as np_version

#useful unicode symbols
chi   = '\u03c7'
pm    = '\u00b1'

mpl.rcParams['font.family'] = 'DejaVu Sans'
plt.rcParams['font.size'] = 10
plt.rcParams['axes.linewidth'] = 2

colors = cm.get_cmap('tab20')
clen = 20

def get_float(txt):
    try:
        return float(txt)
    except Exception as e:
        if (len(txt) > 0): print('note: could not parse',txt,'as float')
        return np.NaN

def is_float(txt):
    """tests if txt can be converted into float (returns True) or not (returns False)"""
    try:
        y = float(txt)
        return True
    except ValueError:
        return False
    
# returns mask where both x and y are valid numbers
# this works also without numpy array. numpy array converts lists into strings if one entry is a string.
def mask_pair(x,y):
    return [((is_float(x[i]) and is_float(y[i]))) for i in range(len(x))]

#returns string in the form value(error)
def str_error(value, error):
    try:
        pwr = np.log10(abs(error))
        pwr = int(math.floor(pwr))
        if pwr < 0: 
            pwr = -pwr
            fmt = '%%.%if(%%i)' % (pwr)
            txt = fmt % (round(value,pwr),int(round(abs(error)*10**pwr)))
        else:
            fmt = '%i(%i)'
            txt = fmt % (int(round(value/10**pwr))*10**pwr,int(round(abs(error)/10**pwr))*10**pwr)
        print('\t\tstr_error note: %f +/- %f = %s' % (value,error,txt))
    except:
        txt = "%f+/-%f" % (value,error);
    return txt

def read(filename, cols=(0,1), scaling=[1,1], skip=0):
    "reads data from CSV file and returns [x,y,..] data"
    cnv={0:get_float, 1:get_float, 2:get_float, 3:get_float, 4:get_float, 5:get_float}
    with io.open(filename, 'rt', encoding='latin1') as file:
        data = np.loadtxt(file, unpack=True, delimiter=',', skiprows=skip, usecols=cols, converters=cnv)
        data = [data[i]*sc for i,sc in enumerate(scaling)]
        return data
    return [[] for _ in cols]

def average(data):
    """
    calculates mean and standard deviation 
    data = [x,y]
    returns list of [x,mean_y,std_y] for each datapoint
    """
    data=np.array(data)
    x,indices = np.unique(data[0],return_inverse=True)
    return np.array([[xi,np.mean(data[1][indices==k]),np.std(data[1][indices==k])] for k,xi in enumerate(x)])

def plot(ax, panel, data, label, model, shade, scale, col, d_args, m_args):
    """
    generic plot of data for all panels
    data = list of data_i per channel with data_i = [data_x,data_y,data_error] with each entry 1d vectors, [] if not used
    label = 1d list of labels for each channel
    model = list of model_i curves for each channel with model_i = [model_x,model_y] with each entry 1d vector, model_i = None if not used
    shade = list of [shade_min_i,shade_max_i] for each channel where shade is drawn between min and max curves consisting of [x,y] with 1d vectors, [] if not used
    scale = 1d list of y-scaling factors for data_y and data_error, 1 = no scaling
    col = 1d list of colors for each channel
    d_args = 1d list of {arguments} for data plot
    m_args = 1d list of {arguments} for model plot
    """
    if ax == None: 
        fig = plt.figure(figsize=(7,7*3/4)) #size in inches
        ax = fig.add_axes([0.1, 0.1, 0.8, 0.8])
        is_panel = False
    else:
        is_panel = True

    xylabel_size    = 16 # axis x and y label fontsize
    tick_labelsize  = 12 # size of tick labels
    text_size       = 12 # size of all text
    legend_fontsize = 16 # size of legend text
    legend_fontsize_b = 14 # size of panel b legend text

    ax.xaxis.set_tick_params(which='major', size=10, width=2, direction='in', top='on'  , labelsize=tick_labelsize)
    ax.xaxis.set_tick_params(which='minor', size=7 , width=2, direction='in', top='on'  , labelsize=tick_labelsize)
    ax.yaxis.set_tick_params(which='major', size=10, width=2, direction='in', right='on', labelsize=tick_labelsize)
    ax.yaxis.set_tick_params(which='minor', size=7 , width=2, direction='in', right='on', labelsize=tick_labelsize)

    if panel == 'jump_0t':
        if not is_panel: ax.set_title('primary pulse leading edge time (t0)')
        #ax.set_xlabel('detector phase (degree)', labelpad=5)
        ax.set_ylabel(r'$N_{RT}$ (cycles)', fontsize=xylabel_size)
        ax.yaxis.set_label_coords(-0.06,0)
        ax.set_xlim(-15, 375)
        y = [m[1][0] for m in model if round(m[1][0]) == m[1][0]]
        y = [np.min(y),np.max(y)]
        print('top jumps y =',y)
        ax.set_ylim(y[0]-0.5, y[0]+1.5)
        ax.set_yticks([y[0],y[0]+1, y[1],y[1]+1])
        #ax.set_yticklabels(['12','13'])
        ax.spines['bottom'].set_visible(False)
        ax.xaxis.tick_top()
        ax.tick_params(labeltop=False)
        # manually place phase labels at given coordinates
        y = y[0] - 0.2
        coords=[(213,y,r'$\phi_{-}$',col[0]),(254,y,r'$\phi_{-}$',col[1])]
        for c in coords:
            ax.text(c[0], c[1], c[2], fontsize=legend_fontsize, rotation=0, ha='center', va='top', color=c[3])
        ax.axvline(x=25, color='k', linestyle='dotted')
    elif panel == 'jump_0b':
        #if not is_panel: ax.set_title('primary pulse leading edge time (t0)')
        ax.set_xlabel('detector phase (degree)', labelpad=5, fontsize=xylabel_size)
        #ax.set_ylabel(r'$N_{RT}$ (cycles)', labelpad=10, fontsize=xylabel_size)
        ax.set_xlim(-15, 375)
        y = [m[1][0] for m in model if round(m[1][0]) == m[1][0]]
        y = [np.min(y),np.max(y)]
        print('bottom jumps y =',y)
        ax.set_ylim(y[0]-0.5, y[0]+1.5)
        ax.set_yticks([y[0],y[0]+1])
        #ax.set_yticklabels(['12','13'])
        ax.spines['top'].set_visible(False)
        ax.xaxis.tick_bottom()
        # manually place phase labels at given coordinates
        y = y[0] + 1.2
        coords=[(25,15.8,r'$\phi_{+}$','black'),(45,y,r'$\phi_{-}$',col[0]),(85,y,r'$\phi_{-}$',col[1])]
        for c in coords:
            ax.text(c[0], c[1], c[2], fontsize=legend_fontsize, rotation=0, ha='center', va='bottom', color=c[3])
        ax.axvline(x=25, color='k', linestyle='dotted')
    elif panel == 't_RT':
        if is_panel: 
            ax.set_xticks([10,15,20,25,30])
            ax.set_xticklabels(['']*5)
        else:
            ax.set_title('round trip time time vs. cable length')
            ax.set_xlabel('cable length (m)', labelpad=5, fontsize=xylabel_size)
        ax.set_ylabel(r'$t_{RT}$ (ns)', labelpad=5, fontsize=xylabel_size)
        ax.set_xlim(9, 32.3)
        ax.set_ylim(210, 570)
        ax.set_yticks([300,400,500])
        # label[0] = mean propagation delay of primary board leading and trailing edge 
        ax.text(0.07, 0.65, label[0], fontsize=legend_fontsize, rotation=0, ha='left', va='bottom', bbox={'boxstyle':'round','alpha':1.0,'facecolor':'white'}, transform=ax.transAxes)
    elif panel == 'phase':
        ax.set_xlabel('cable length (m)', labelpad=2, fontsize=xylabel_size)
        ax.set_ylabel('phase (degree)', labelpad=0, fontsize=xylabel_size)
        ax.set_xlim(9, 32.3)
        ax.set_ylim(-30, 390)
        ax.set_yticks([0,90,180,270,360])
        ax.axhline(y=180, color='k', linestyle='dotted', zorder=1)
        # label[3] = mean propagation delay of secondary board leading and trailing edge 
        ax.text(0.07, 0.035, label[3], fontsize=legend_fontsize, rotation=0, ha='left', va='bottom', bbox={'boxstyle':'round','alpha':1.0,'facecolor':'white'}, transform=ax.transAxes)
    elif panel == 'sync_error':
        if not is_panel: ax.set_title('synchronization error vs. cable length')
        ax.set_xlabel('cable length (m)', labelpad=5, fontsize=xylabel_size)
        ax.set_ylabel('error (ns)', labelpad=10, fontsize=xylabel_size)
        ax.set_xlim(9, 32.3)
        ax.set_xticks([10,15,20,25,30])
        limits = [-4,5]
        ax.set_ylim(limits[0], limits[1])
        ticks = [-3,0,3]
        ax.set_yticks(ticks)
        ax.text(0.07, 0.825, label[0], fontsize=legend_fontsize, rotation=0, ha='left', va='top', bbox={'boxstyle':'round','alpha':1.0,'facecolor':'white'}, transform=ax.transAxes)
        # remove the upper tick on the right y-axis
        ax2 = ax.twinx()
        ax2.yaxis.set_tick_params(which='major', size=10, width=2, direction='in', right='on')
        ax2.yaxis.set_tick_params(which='minor', size=7 , width=2, direction='in', right='on')
        ax2.set_ylim(limits[0], limits[1])
        ax2.set_yticks(ticks[0:-1])
    elif panel == 'traces':
        ax.set_ylabel('signal (V)', labelpad=3.5, fontsize=xylabel_size, bbox={'facecolor':'white','edgecolor':'None'})
        ax.set_xlabel('time (ns)', labelpad=0, fontsize=xylabel_size)
        ax.set_xlim(-7, 7)
        ax.set_xticks([-5,0,5])
        ax.set_ylim(-1,5)
        ax.set_yticks([0,2,4])
        if not is_panel:
            ax.text(0.05, 0.67, label[-1], fontsize=legend_fontsize, rotation=0, ha='left', va='top', bbox={'boxstyle':'round','alpha':1.0,'facecolor':'white'}, transform=ax.transAxes)
    elif panel == 'corr':
        ax.set_ylabel('error (ns)', labelpad=5, fontsize=xylabel_size)
        #ax.set_xlabel(r'$270^{\circ}-\tau_c\,\frac{360^{\circ}}{T} - \phi_{ext}$ (degree)', labelpad=2, fontsize=xylabel_size)
        ax.set_xlabel(r'$\phi_{ext} + \tau_c\,\frac{360^{\circ}}{T}$ (degree)', labelpad=2, fontsize=xylabel_size)
        ax.set_xlim(215, 295)
        ax.set_xticks([220,240,260,280])
        ax.set_ylim(-4.0,4.0)
        ax.set_yticks([-3,0,3])
        ax.axhline(y=0, color='k', linestyle='dotted', zorder=1)
        ax.axvline(x=263, color='k', linestyle='dotted', zorder=1)
    elif panel == 'jumps':
        ax.set_title(label[-1])

    for i,d in enumerate(data):
        #shaded region between two curves
        if (len(shade[i]) > 0):
            x = shade[i][0]
            y0 = scale[i]*shade[i][1]
            y1 = scale[i]*shade[i][2]
            col_rgb=mpl.colors.to_hex(col[i])+"50" # add transparency: 0 = fully transparent, ff = opaque
            ax.fill_between(x, y0, y1, facecolor=col_rgb, interpolate=False) #'paleturquoise'
        #model curve
        if len(model[i]) != 0: #plot model if not None
            if (len(d) == 0):
                ax.plot(model[i][0], scale[i]*model[i][1], color=col[i], label=label[i], zorder=1, **m_args[i])
            else:
                ax.plot(model[i][0], scale[i]*model[i][1], color=col[i], zorder=1, **m_args[i])
        if (len(d) > 0):
            if len(d) == 2: # get mean and std
                xy = np.transpose(average(d))
                print("note: get mean and std")
            else: # data already contains mean and std
                xy = d
            if scale[i] != 1: 
                print('*** ATTENTION: %s scaled x %i ***' % (label[i],scale[i]))
                xy[1] = xy[1]*scale[i]
                xy[2] = xy[2]*scale[i]
                y=np.array(sorted(xy[1], key=lambda x: x[0]))
                ax.text(y[-1][0], y[-1][1]+30, "x"+str(scale[i]), fontsize=legend_fontsize, rotation=0, ha='right', va='bottom', color=col[i])
            # plot error bars with scaling = sc
            sc = 1
            if len(xy) == 3: # y-error bar
                for j in range(len(xy[0])):
                    ax.plot([xy[0][j],xy[0][j]], [xy[1][j]-sc*xy[2][j],xy[1][j]+sc*xy[2][j]], color=col[i], linestyle='solid', linewidth=2, zorder=1)
            else: # xy-error bar
                for j in range(len(xy[0])):
                    ax.plot([xy[0][j],xy[0][j]], [xy[1][j]-sc*xy[3][j],xy[1][j]+sc*xy[3][j]], color=col[i], linestyle='solid', linewidth=2, zorder=1)
                    ax.plot([xy[0][j]-sc*xy[2][j],xy[0][j]+sc*xy[2][j]], [xy[1][j],xy[1][j]], color=col[i], linestyle='solid', linewidth=2, zorder=1)
            # plot mean values
            ax.scatter(xy[0], xy[1], color=col[i], label=label[i], zorder=2, **d_args[i])

    if ((is_panel==False) or (panel == 'jump_0') or (panel == 'jump_0b') or (panel == 'phase') or (panel=='traces') or panel=='corr') and not np.all(np.array(label)==None) and not panel == 'sync_error':
        if (panel == 'jump_0'):
            ax.legend(bbox_to_anchor=(0.99, 0.99), loc='upper right', frameon=True, fontsize=legend_fontsize, ncol=1, framealpha=1.0, edgecolor='black')
        if (panel == 'jump_0b'):
            ax.legend(bbox_to_anchor=(0.98, 0.3), loc='lower right', frameon=True, fontsize=legend_fontsize, ncol=1, framealpha=1.0, edgecolor='black')
        elif (panel == 'phase'):
            ax.legend(bbox_to_anchor=(0.5, 1.0), loc='upper center', frameon=True, fontsize=legend_fontsize, ncol=3, framealpha=1.0, edgecolor='black')
        elif (panel == 'traces'):
            ax.axvline(x=-0.5-1.3, color='k', linestyle='dotted')
            ax.axvline(x=-0.5+1.3, color='k', linestyle='dotted')
            if is_panel: ax.legend(bbox_to_anchor=(0.99, 0.07), loc='lower right', frameon=True, fontsize=10, ncol=1, framealpha=1.0, edgecolor='black')
            else: ax.legend(bbox_to_anchor=(0.05, 0.95), loc='upper left', frameon=True, fontsize=legend_fontsize, ncol=1, framealpha=1.0, edgecolor='black')
        elif panel == 'corr':
            leg=ax.legend(bbox_to_anchor=(0.01, 0.99), loc='upper left', frameon=True, fontsize=legend_fontsize_b, ncol=2, framealpha=1.0, edgecolor='black', title=r'$\tau_c\,\frac{360^{\circ}}{T}$')
            plt.setp(leg.get_title(),fontsize=legend_fontsize_b) #title_fontsize does not work, but this works!
        elif panel == 'jumps':
            ax.legend(bbox_to_anchor=(1.0, 0.95), loc='upper left', frameon=True, fontsize=10, ncol=1, framealpha=1.0, edgecolor='black')
        else:
            ax.legend(bbox_to_anchor=(0.05, 0.95), loc='upper left', frameon=True, fontsize=legend_fontsize, ncol=1, framealpha=1.0, edgecolor='black')

    if (is_panel == False):
        plt.savefig('figure_8.pdf', dpi=300, transparent=False, bbox_inches='tight')

def panel(data, label, model, shade, scale, col, d_args, m_args):

    fig = plt.figure(figsize=(7,7)) #*3/4 size in inches

    #panels from top to bottom
    panels = ['jump_0t','jump_0b','t_RT','sync_error']
    panels_text = ['a',None,'b','c']
    width = 0.9
    height = [0.14,0.14,0.3,0.3]
    gap = [0.02,0.08,0,0.05]
    left = 0.09
    # insert [x,y,w,h]
    insert = [0.67,0.285,0.32,0.25]

    ax = [None for p in panels]
    for i,p in enumerate(panels):
        y_top = sum(gap[i:]) + sum(height[i:]) # y top coordinate of panel
        ax[i] = fig.add_axes([left, y_top-height[i], width, height[i]])
        plot(ax[i], p, data[i], label[i], model[i], shade[i], scale[i], col[i], d_args[i], m_args[i])
        if panels_text[i] is not None: plt.text(0.0,y_top,panels_text[i],fontsize=16,transform=fig.transFigure,verticalalignment='top')

    if len(insert) > 0:
        i = -1
        ax = fig.add_axes(insert)
        plot(ax, 'traces', data[i], label[i], model[i], shade[i], scale[i], col[i], d_args[i], m_args[i])

    plt.savefig('figure_6.pdf', dpi=300, transparent=False, bbox_inches='tight')

def panel2(data, label, model, shade, scale, col, d_args, m_args):

    fig = plt.figure(figsize=(7,7)) #*3/4 size in inches

    #panels from top to bottom
    panels = ['phase','corr']
    panels_text = ['a','b']
    width = 0.9
    height = [0.55,0.30]
    gap = [0.08,0.06]
    left = 0.09

    ax = [None for p in panels]
    for i,p in enumerate(panels):
        y_top = sum(gap[i:]) + sum(height[i:]) # y top coordinate of panel
        ax[i] = fig.add_axes([left, y_top-height[i], width, height[i]])
        plot(ax[i], p, data[i], label[i], model[i], shade[i], scale[i], col[i], d_args[i], m_args[i])
        if panels_text[i] is not None: plt.text(0.0,y_top,panels_text[i],fontsize=16,transform=fig.transFigure,verticalalignment='top')

    plt.savefig('figure_8.pdf', dpi=300, transparent=False, bbox_inches='tight')

def sum_of_nearest(x,y,v):
    """
    find nearest y to linear function of x with v[0] = offset and v[1] = slope.
    y and function are taken modulo cycle_time.
    2 possibilities: (y-f)%cycle_time and (f-y)%cycle_time and we take smallest.
                     both give positive result but one is e and the other is cycle_time-e.
    returns sum of squared errors.
    """
    err = v[0] + x*v[1] - y
    err = np.transpose([err % cycle_time,(-err) % cycle_time])
    return np.sum([np.min(e)**2 for e in err])

def error_of_nearest(x,y,v):
    """
    return error vector and not sum of squares as for sum_of_nearest
    """
    err = v[0] + x*v[1] - y
    err = np.transpose([err % cycle_time,(-err) % cycle_time])
    return [np.min(e) for e in err]

def map_360(y):
    """
    map angle 0..360 degree. 
    in python modulo is sufficient since maps to positive side but not in C/C++.
    for demonstration we use C-style here, where negative case would be: 360 + (y % 360)
    """
    if isinstance(y,list) or isinstance(y,np.ndarray): return np.array(y) % 360
    else: 
        #return y % 360
        if y < 0: return 360 - ((-y) % 360)
        else: return y % 360

def angle_diff(x,y):
    """
    returns the smallest difference in angles y-x (angles in degree). 
    the sign is positive when x rotated into y is counter-clockwise.
    """
    x = x % 360
    y = y % 360
    d = y-x
    if (abs(d) < abs(360-abs(d))): return d
    else: return -d/abs(d)*(360-abs(d))

def angle_avg(x,y):
    """
    returns the average of the angles x,y (in degree, might be negative). 
    """
    return map_360(x + angle_diff(x,y)/2)

def angle_avg_v(y):
    """
    returns the average of the angles in vector y (in degree, mapped [0..360[). 
    """
    if len(y) == 1: return y
    else: 
        x = y[0]
        avg = map_360(x + np.mean([angle_diff(x,yi) for yi in y]))
        return map_360(x + np.mean([angle_diff(x,yi) for yi in y[1:]]))

def get_fi_ext(fi_p,fi_s):
    """returns external clock PLL set phase calcuated from primary and secondary pulse phase"""
    global PHASE_CORR, SEC_PH_OFF0
    return map_360(fi_s - fi_p - PHASE_CORR)

def get_ext_det_phase(fi_p, fi_s, label):
    """
    calculate external and detection phase from primary and secondary pulse phase. 
    input primary and secondary pulse phase in degree. label used in warning text.
    returns [external phase,detection phase, wait] with phases indegree and 
    wait = True if has to wait one cycle longer, otherwise False. 
    """
    global PHASE_DET, PHASE_MARGIN, PHASE_CORR, PHASE_PLUS, PHASE_CRNG, PHASE_CADD
    # critical phase: when fi_p is close to fi_crit then result is unreliable
    fi_crit = map_360(360 - PHASE_MARGIN - PHASE_CORR - PHASE_DET)
    # external PLL clock phase
    fi_ext = map_360(fi_s - fi_p - PHASE_CORR)
    # add/subtract PHASE_CADD when within PHASE_CRNG to critical phase
    # this will increase synchronization error but it will not jump by cycle_time.
    if (abs(fi_p-fi_crit) < PHASE_CRNG):
        if fi_p >= fi_crit: 
            print('warning: %s near fi_crit=%.1f! %d degrees subtracted from fi_ext.' % (label, fi_crit, PHASE_CADD))
            fi_ext -= PHASE_CADD
        else:               
            print('warning: %s near fi_crit=%.1f! %d degrees added to fi_ext.' % (label, fi_crit, PHASE_CADD))
            fi_ext += PHASE_CADD
    # detection phase
    # TODO: not sure if to add PHASE_CORR and PHASE_CADD here? this is how is done on board now.
    fi_det = fi_p + PHASE_CORR + PHASE_DET
    if fi_det < 0: fi_det = fi_det + 360
    # ensure fi_det is not too close to bus clock. add 1 cycle if larger than 360 degree.
    if fi_det < PHASE_MARGIN: return [fi_ext,PHASE_MARGIN,False]
    elif (fi_det + PHASE_MARGIN) > 360: # add 1 cycle 
        print('note: %s fi_det = %.3f add one cycle.' % (label, fi_det))
        fi_det = fi_det - 360
        if fi_det < PHASE_MARGIN: return [fi_ext,PHASE_MARGIN,True]
        else: return [fi_ext,fi_det,True]
    else: return [fi_ext,fi_det,False]


def arctan(x,x0,k,y_neg,y_pos,sigma=0):
    # sigma not used. for consistency with smooth_slope.
    return y_neg+(y_pos-y_neg)*(0.5+np.arctan((x-x0)*k)/np.pi)

def get_offset_arctan(x,y):
    "fits arctan into curve to get x-coordinate where amplitude is half"
    #this works but the function does not represent very well the data.
    par = [0.0,1.0,0.0,4.0] # [x0, k=slope, y-, y+]
    par, cov = curve_fit((lambda x,x0,k,y_neg,y_pos: arctan(x,x0,k,y_neg,y_pos)), x, y, p0 = par)
    err = np.sqrt(np.diag(cov))
    # return sigma for consistency with get_offset_slope
    par = par.tolist() + [0]
    err = err.tolist() + [0]
    return [par,err] # return [[x0,slope,y-,y+,0],error of [x0,slope,y-,y+,0]]

def slope(x,x0,k,y_neg,y_pos):
    width = (y_pos-y_neg)/(2*k) 
    if   x <= (x0-width): return y_neg
    elif x >= (x0+width): return y_pos
    else: return (y_pos+y_neg)/2 + (x-x0)*k

def Gauss(x,sigma):
    y = np.exp(-x**2/(2*sigma**2))
    return y/np.sum(y)

def smooth_slope(x,x0,k,y_neg,y_pos,sigma):
    """
    generates a smooth slope function with a Gauss kernel.
    x = x-values. assumed with equal spacings
    x0 = x-coordinate of step
    sigma = Gaussian sigma
    y_neg = y-value for x < x0
    y_pos = y-value for x > x0
    returns y-values for given x-values
    adds datapoints left and right before convolution and cuts away afterwards, to avoid edge effects.
    """
    x = np.array(x)
    dx = x[1]-x[0]
    width = np.max([3*sigma,5*dx]) # kernel includes +/-3x sigma or +/-5 steps
    kx = np.arange(-width,width+dx,dx)
    steps = len(kx)
    kernel = Gauss(kx,sigma)
    y = [slope(xi,x0,k,y_neg,y_pos) for xi in np.arange(x[0]-steps*dx,x[-1]+(steps+1)*dx,dx)]
    return np.convolve(y,kernel,mode='same')[steps:len(y)-steps]

def get_offset_slope(x,y):
    """
    fits Gauss-filtered slope function into curve y(x) to get x-coordinate where amplitude is half.
    returns [[x0, slope, y-, y+, sigma], error of [x0, slope, y-, y+, sigma]]
    """
    par = [1.0,2.0,0.0,4.0] # starting parameters [x0, slope, y-, y+]
    sigma = 2.0 # starting sigma or fixed sigma
    fit_sigma = False # fit sigma if true. fit often does not work like this. fixed sigma has less troubles.
    fit_sigma_th = 1000 # if fit_sigma and x0 error is larger this then try with fixed signa
    # unfortunately, the oscilloscope saved only 14 datapoints, so we copy the first and last datapoint 'add' times left and right for better fitting
    dx = x[1] - x[0] # we assume fixed x-step which is the case for our data
    add = 0
    if add > 0:
        x = np.concatenate([np.arange(x[0]-add*dx,x[0],dx), x, np.arange(x[-1]+dx,x[-1]+(add+1)*dx,dx)])
        y = np.concatenate([[y[0]]*add, y, [y[-1]]*add])
    # get starting parameters from arctan fit (without sigma)
    par, cov = curve_fit(arctan, x, y, p0 = par)
    par = par.tolist() + [sigma] # add sigma to starting parameter
    chi2_start = np.sum((smooth_slope(x, *par) - y)**2)
    if fit_sigma: # fit sigma (gives often big error for slope and x0 or does not converge)
        try:
            par, cov = curve_fit(smooth_slope, x, y, p0 = par) #, bounds = [par-1,par+1], method='trf')
            err = np.sqrt(np.diag(cov))
        except RuntimeError:
            err = [fit_sigma_th]
    else: err = [0]
    if (err[0]>=fit_sigma_th):
        print('warning: x0 error = %.1f > %i! fit with fixed sigma = %.1f' % (err[0], fit_sigma_th, sigma))
        fit_sigma = False
    if fit_sigma == False: # use fixed sigma
        par, cov = curve_fit(lambda x, x0, k, y_neg, y_pos: smooth_slope(x, x0, k, y_neg, y_pos, sigma), x, y, p0 = par[0:-1]) #, bounds = [par-1,par+1], method='trf')
        err = np.sqrt(np.diag(cov))        
        par = par.tolist() + [sigma]
        err = err.tolist() + [0]
    chi2_fit = np.sum((smooth_slope(x, *par) - y)**2)
    #print(par)
    #print(err)
    #print("chi^2 start %f -> fit %.3f" % (chi2_start, chi2_fit))
    return [par,err] # return fit result and error

#find jump in y by fitting a Gaussian on derivative of mean value d<y>/dx
def find_jump(x, y):
    # get unique entries and indices such that xu[indices] = x
    # we round to about 1/1120 in phase to avoid numerical uncertainties which otherwise create large derivative
    xu, i = np.unique(np.around(x,3), return_inverse=True)
    # get mean value for all unique x-values
    ym = np.array([np.mean(y[i == j]) for j in range(len(xu))])
    # derivative dy/dx
    xm = (xu[1:]+xu[0:-1])/2
    dy = (ym[1:]-ym[0:-1])/(xu[1:]-xu[0:-1])
    # add width 0s at both edges
    width = 5
    dx = (xm[1]-xm[0]+xm[-1]-xm[-2])/2
    dx = np.arange(dx,(width+1)*dx,dx)
    xm = np.concatenate([xm[0]-dx,xm,xm[-1]+dx])
    dy = np.concatenate([[0]*width,dy,[0]*width])
    # take absolute value  
    dy = np.abs(dy)
    if False: # Gauss filter after derivative. has a bias when the data is left/right not same distributed which is here the case, so keep off.
        sigma = 2.5 # Gauss sigma in degree
        width = 5 # number of nearest neighbors to include (>=1)
        if len(dy) > 2*width + 1:
            dy = [np.sum([dy[i-j]*np.exp(-0.5*((xi-xm[i-j])**2)/(sigma**2)) for j in range(-width,width+1,1)])/(np.sqrt(2*np.pi)*sigma) for i,xi in enumerate(xm[width:-width])]
            #dy = [np.sum(dy[i-width:i+width+1])/(2*width+1) for i in range(width,len(xm)-width)] # square filter for testing
            xm = xm[width:-width]
        else:
            print('warning: data length too short for Gauss filter!')
    # start values
    ymax = np.max(dy)
    ymin = np.min(dy)
    x0_start = xm[dy == ymax][0]
    sigma_start = (xu[-1] - xu[0])/10
    if 3*sigma_start > np.abs(ymax - ymin): sigma_start = np.abs(ymax - ymin)/3
    try: # Gauss fit of |derivative|
        par, cov = curve_fit((lambda x,x0,sigma,a: a*np.exp(-0.5*(x-x0)**2/(sigma**2))), xm, dy, p0 = [x0_start,sigma_start,1])
        err = np.sqrt(np.diag(cov))
        if np.any([~np.isfinite(e) for e in err]): ok = 0 # check inf in error
        else: ok = 1
    except RuntimeError:
        print('Gauss fit runtime error! (return starting values)')
        par = [x0_start,sigma_start,1]
        err = [1,1,1]
        ok = 0
    # get fitted Gaussian
    ymin = np.min(y)
    ymax = np.max(y)
    dx = 10*par[1]/100
    x_fit = np.arange(par[0]-5*par[1],par[0]+5*par[1],dx)
    y_fit = np.exp(-0.5*(x_fit-par[0])**2/(par[1]**2))*(ymax-ymin)
    # get fitted curve by integration over Gaussian
    #yfit = ymax - int_array(np.exp(-0.5*(xfit-par[0])**2/(par[1]**2)))*(ymax-ymin)*dx/(np.sqrt(2*np.pi)*par[1])
    #return [[x0, sigma, error x0, error sigma, t_low, t_high, 1 if fit is ok], [x_Gauss, y_Gauss]]
    #return [[par[0], par[1], err[0], err[1], ymin, ymax, ok], [xm, dy]] for testing return data which is used for fit
    return [[par[0], par[1], err[0], err[1], ymin, ymax, ok], [x_fit, y_fit]]


##########################################################################################################
# constants
##########################################################################################################

# auto-sync constants
# fit primary board RT time vs. cable length [board uses t1]
PRIM_RT_SPEED0  = 4.5   # speed in ns/m t0 (rising edge) 4.4/4.5
PRIM_RT_SPEED1  = 5.27  # speed in ns/m t1 (falling edge) 5.28/5.27
PRIM_RT_OFF0    = 181   # offset in ns t0 (174/181)
PRIM_RT_OFF1    = 205   # offset in ns t1 (194/205)
PRIM_RT_OFF_ERR = 1     # error offset in ns (typical error always around 1ns)
# fit secondary board phase vs. cable length [board uses t0]
SEC_PH_SPEED0   = 5.29  # speed in ns/m t0 (rising edge) 5.29
SEC_PH_SPEED1   = 5.1   # speed in ns/m t1 (falling edge) 5.1
SEC_PH_OFF0     = -2    # offset in ns t0 (3/-2)
SEC_PH_OFF1     = -1    # offset in ns t1 (2/-1)
SEC_PH_OFF_ERR  = 5     # error offset in ns (typical around 1-8ns)
# phase calculation
PHASE_PLUS      = 25    # phase of positive jump in degree
PHASE_DET       = 70    # detection phase with respect to pulse. adjust this for threshold above which 1 cycle is added
PHASE_MARGIN    = 90    # phase margin
PHASE_CORR      = 20    # phase correction to match external clock phase (6.6/20*30 degree)
PHASE_CORR_EXT  = -103  # difference fi_s - fi_p + fi_ext. should be 0 but it is somehow around -90 degree?
PHASE_CRNG      = 20    # critical range within fi_p_crit
PHASE_CADD      = 30    # added phase when within critical range
# waiting time calculation
WAIT_ADD        = 3     # cycles to add for waiting time

# globals
deg_cal = 1120      # steps for 360 degrees
xoff    = 0         # phase offset, use to shift by 180 degree if wanted
yoff    = 0*4/3     # y offset in ns for jumps
reps    = 5         # number of repetitions for lower/upper boundaries
offset  = [0,0]     # time offset for [t0,t1]
cycle_time = 20     # ns per cycle
fit_xmin = 3.0      # fit data only >= xmin
speed_of_light = 299792458 # m/s
RG58    = 0.66      # velocity factor of cable
speed   = 1e9/(speed_of_light*RG58) # expected propagation speed in ns/m
correct_p_jump = True  #primary board: add one cycle if phase is < p_jump
correct_s_jump = False  #secondary borad: add one cycle if phase is < s_jump [not needed]
p_jump = [PHASE_PLUS,2] # primary   board jump in time phase in degree +/- error
s_jump = [PHASE_PLUS,2] # secondary board jump in time phase in degree +/- error
USE_TEST_PRIM_T0 = 0    # index into result
USE_TEST_PRIM_T1 = 1    # index into result
USE_TEST_SEC_T0  = 2    # index into result
USE_TEST_SEC_T1  = 3    # index into result
USE_TEST_RESULT  = 8    # summary of board result

# select if synchronization error is taken from fit (True) or from manually measured error on scope (False)
use_err_fit = True

#data series
series = 'data_1'

# folder with traces
tr_folder = series+'/osci/'

# folders and corresponding external clock phase
folders = ['data_0','data_90','data_180','data_270']   # list of data folders
ext_clk = [0,90,180,270] # list of primary output clock phase in degrees

f_sel = folders[1]        # folder to show for selected data
sel   = ['20m','20.3m','30m','30.3m'] # selected cable lengths (labels) for jumps (panel a), empty for all

#init data for combined plots
label_all        = [None]*len(folders)
cables           = [None]*len(folders)
trace_i          = [None]*len(folders)
sync_error       = [None]*len(folders)
sync_error_err   = [None]*len(folders)
p_delay          = [None]*len(folders)
p_phase          = [None]*len(folders)
s_phase          = [None]*len(folders)
s_ext            = [None]*len(folders)
s_ext_orig       = [None]*len(folders)
s_det            = [None]*len(folders)
p_delay_err      = [None]*len(folders)
p_phase_err      = [None]*len(folders)
s_phase_err      = [None]*len(folders)
s_ext_err        = [None]*len(folders)
s_det_err        = [None]*len(folders)
p_data           = [None]*len(folders)
p_t0             = [None]*len(folders)
p_t0_err         = [None]*len(folders)
p_t1             = [None]*len(folders)
p_t1_err         = [None]*len(folders)
p_ph0            = [None]*len(folders)
p_ph0_err        = [None]*len(folders)
p_ph1            = [None]*len(folders)
p_ph1_err        = [None]*len(folders)
p_RT_t0          = [None]*len(folders)
p_RT_t0_err      = [None]*len(folders)
p_RT_t1          = [None]*len(folders)
p_RT_t1_err      = [None]*len(folders)
p_fit0           = [None]*len(folders)
p_fit1           = [None]*len(folders)
p_par0           = [None]*len(folders)
p_par1           = [None]*len(folders)
p_err0           = [None]*len(folders)
p_err1           = [None]*len(folders)
fi_RT_fit        = [None]*len(folders)
s_t0             = [None]*len(folders)
s_t0_err         = [None]*len(folders)
s_t1             = [None]*len(folders)
s_t1_err         = [None]*len(folders)
s_ph0            = [None]*len(folders)
s_ph0_err        = [None]*len(folders)
s_ph1            = [None]*len(folders)
s_ph1_err        = [None]*len(folders)
s_par0           = [None]*len(folders)
s_par1           = [None]*len(folders)
s_err0           = [None]*len(folders)
s_err1           = [None]*len(folders)
s_fit0           = [None]*len(folders)
s_fit1           = [None]*len(folders)

##########################################################################################################
# load and analyze all data folders
##########################################################################################################

for f,folder in enumerate(folders):

    # data contains [cable length in m, list of sync error in ns, list of trace file number corresponding to each error]
    # sync error = (t_sec - t_prim) in ns measured manually with osci cursors.

    if series == 'data_1':
        if folder == 'data_0': 
            data = [  [10.0,[0.80,0.92,0.72,1.04,0.88],[216,217,218,219,220]], 
                      [10.3,[0.36,0.40,0.32,0.32,-0.20],[196,197,198,199,200]],
                      [11.0,[-1.72,-1.76,-1.64,-1.48,-1.16],[175,176,177,178,179]],
                      [11.3,[-2.24,-2.12,-2.12,-1.68,-1.68],[158,159,160,161,162]],
                      [20.0,[-2.32,-2.28,-2.20,-2.24,-2.28],[138,139,140,141,142]], #+here subtracts for all 73 steps!
                      [20.3,[0.00,0.28,0.12,0.16,0.24],[118,119,120,121,122]], 
                      [21.0,[1.20,1.08,1.48,1.08,1.24],[98,99,100,101,102]], #restart here after ca. 1h lunch break
                      [21.3,[2.16,1.96,2.04,2.36,2.28,2.08,1.72],['-',77,78,79,80,81,82]], #forgot to save first trace
                      [30.0,[-1.0,-0.96,-0.96,-1.0,-0.92],[61,62,63,64,65]], 
                      [30.3,[-1.28,-1.24,-1.28,-1.08,-1.0],[41,42,43,44,45]], #*short cable error, touched couplers and restarted ok
                      [31.0,[-0.80,-1.24,-1.08,-1.28,-1.28],[21,22,23,24,25]],
                      [31.3,[1.32,1.20,1.12,1.24,1.36],[1,2,3,4,5]]
                ]
        elif folder == 'data_90':
            data = [  [10.0,[1.48,1.72,1.36,1.48,1.48],[221,222,223,224,225]], 
                      [10.3,[0.96,0.80,0.92,1.04,0.36],[201,202,203,204,205]],
                      [11.0,[-1.08,-1.08,-1.24,-1.08,-1.16,-1.16],[180,181,182,183,184,185]], 
                      [11.3,[-1.68,-1.64,'-',-2.12,-2.12,-2.08],[163,164,'-',165,166,167]], #had to repeat because of Osci trigger failure
                      [20.0,[-2.64,-2.96,-2.76,-2.76,-2.72],[143,144,145,146,147]], #++
                      [20.3,[-0.36,-0.44,-0.28,0.64,-0.28],[123,124,125,126,127]], #has some problems to find jump sec t0- but after several restarts its ok
                      [21.0,[1.48,1.52,1.56,1.52,1.16],[103,104,105,106,107]], 
                      [21.3,[2.20,2.08,2.56,2.32,'-',2.44],[83,84,85,86,'-',87]], #**repeated since osci triggered wrongly
                      [30.0,[-0.56,-0.32,-0.48,-0.40,-0.48],[66,67,68,69,70]],
                      [30.3,[-0.48,-0.48,-0.68,-0.64,-0.60],[46,47,48,49,50]], 
                      [31.0,[-1.12,-0.88,-0.88,-0.76,-0.80],[26,27,28,29,30]], 
                      [31.3,[1.20,1.16,1.04,1.04,1.04],[6,7,8,9,10]]
                ]
        elif folder == 'data_180':
            data = [  [10.0,[1.44,1.40,1.48,1.48,1.48],[226,227,228,229,230]], 
                      [10.3,[0.68,0.36,0.84,0.44,0.92],[206,207,208,209,210]], 
                      [11.0,[-0.96,-0.96,-0.80,-1.0,-1.0],[186,187,188,189,190]], 
                      [11.3,[-1.88,-1.88,-1.84,-1.72,'-',-1.88,-1.88,-1.84],[168,169,170,171,'-',172,173,174]], #*outside of osci zoom region or osci did not triggered? repeated always ok.
                      [20.0,[-2.40,-2.40,-2.64,-2.32,-2.68],[148,149,150,151,152]], #++
                      [20.3,[-0.28,-0.12,-0.30,-0.28,-0.36],[128,129,130,131,132]], 
                      [21.0,[0.72,0.88,0.80,1.16,1.12],[108,109,110,111,112]], 
                      [21.3,[2.60,2.44,2.36,2.48,2.56],[88,89,90,91,92]],
                      [30.0,[-0.16,-0.24,-0.20,-0.20,-0.16],[71,72,73,74,75]], 
                      [30.3,[-0.52,-0.40,-0.44,-0.52,-0.44],[51,52,53,54,55]], 
                      [31.0,[-0.72,-0.64,-0.72,-0.72,-0.64],[31,32,33,34,35]], 
                      [31.3,[1.12,1.04,1.20,1.16,1.20],[11,12,13,14,15]]
                ]
        elif folder == 'data_270':
            data = [  [10.0,[1.00,0.80,1.00,1.40,1.24],[231,232,233,234,235]], 
                      [10.3,[0.16,0.16,0.32,0.24,0.28],[211,212,213,214,215]],
                      [11.0,[-1.32,-1.32,-1.40,-1.40,-1.44],[191,192,193,194,195]], 
                      #[11.3,[-],[-]], problems finding jump sec t0-, left it running for a while but nerver found anything
                      [20.0,[-2.08,-2.16,-2.24,-1.88,-2.32],[153,154,155,156,157]], #++
                      [20.3,[0.32,0.16,0.00,0.16,0.16],[133,134,135,136,137]], 
                      [21.0,[1.12,0.96,1.12,1.08,0.88],[113,114,115,116,117]], 
                      [21.3,[1.76,1.64,1.72,1.76,1.68],[93,94,95,96,97]], #stop here for lunch break
                      [30.0,[-2.00],[76]], #problems to find sec t0- jump!
                      [30.3,[-0.92,-0.88,-0.84,-0.84,-0.92],[56,57,58,59,60]],
                      [31.0,[-1.44,-1.0,-0.88,-0.80,-0.88],[36,37,38,39,40]], 
                      [31.3,[1.24,1.32,1.12,1.12,1.24],[16,17,18,19,20]]
                ]

    # ensure that same number of traces and measurements
    test = [(len(d[1])!=len(d[2])) for d in data]
    if np.any(test):
        d=data[np.arange(len(data))[test][0]]
        print("folder %s cable %.1fm traces %d != measurements %d!" % (folder, d[0], len(d[2]), len(d[1])))
        sys.exit(0)
    
    # mask non-numeric data
    data_orig = data
    data = [(lambda mask: [d[0],[di for i,di in enumerate(d[1]) if mask[i]],[di for i,di in enumerate(d[2]) if mask[i]]])(mask_pair(d[1],d[2])) for d in data]

    # split data into cables and sync_error
    cables[f]         = [int(d[0]) if round(d[0])==d[0] else d[0] for d in data]
    sync_error[f]     = [np.mean([y for y in d[1] if is_float(y)]) for d in data]
    sync_error_err[f] = [np.std([y for y in d[1] if is_float(y)]) for d in data]

    # get trace indices for each cable
    trace_i[f] = [d[2] for d in data]

    # labels
    label_all[f] = [str(l) +'m' for l in cables[f]]

    ##########################################################################################################
    # result file contains summary of auto-sync measurement done by both boards. this is main data.
    ##########################################################################################################

    # search result [#,time_low,time_high,phase_low,phase_high] 
    # with #=[0..8] corresponding to [prim_t0-,prim_t1-,sec_t0-,sec_t1-,prim_t0+,prim_t1+,sec_t0+,sec_t1+,summary of boards]
    # the first 4 are the different measurements of finding the negative jump on primary and secondary board
    # t0-/+ = leading edge negative/positive jump, t1-/+ = trailing edge negative/positive jump
    # time_low/high = lower upper RT time in cycles (difference must be 1 cycle)
    # phase_low/high = lower/upper phase of jump in degree
    # summary of boards contains [8,propagation time in ps,secondary phase in steps,external clock phase in steps,detector clock phase in steps]

    name = 'result_prim_'
    files = [series+'/prim/'+folder+'/'+name+ph+'.csv' for i,ph in enumerate(label_all[f])]
    result = [np.array(read(f,(0,1,2,3,4),[1,1,1,1,1],skip=0)) for f in files]
    # remove nan's
    result = [np.transpose(np.transpose(d)[~(np.isnan(d[0]) | np.isnan(d[1]) | np.isnan(d[2]) | np.isnan(d[3]) | np.isnan(d[4]))]) for d in result]

    # load primary delay, secondary external and detector clock phase and error from summary
    index = USE_TEST_RESULT
    r0             = [np.transpose(np.transpose(r)[r[0]==index]) for r in result]
    p_delay[f]     = np.array([np.mean(r[1])/1000 for r in r0]) # propagation time in ns
    p_phase[f]     = (((p_delay[f] + PRIM_RT_OFF1) % cycle_time)*360)/cycle_time
    s_phase[f]     = np.array([angle_avg_v(r[2]*360/deg_cal) if (len(r[3]) > 1) else r[2][0]*360/deg_cal for r in r0]) # fi_s with SEC_PH_OFFSET already subtracted
    s_ext[f]       = np.array([angle_avg_v(r[3]*360/deg_cal) if (len(r[3]) > 1) else r[3][0]*360/deg_cal for r in r0])
    #s_ext_orig[f]  = [r[3]*360/deg_cal for r in r0]
    s_det[f]       = np.array([angle_avg_v(r[4]*360/deg_cal) if (len(r[3]) > 1) else r[4][0]*360/deg_cal for r in r0])

    # each datapoint must have a corresponding s_ext_orig, otherwise we cannot calculate correlation
    #test = [(len(d[1])!=len(s_ext_orig[f][i])) for i,d in enumerate(data_orig)]
    #if np.any(test):
    #    i = np.arange(len(data_orig))[test][0]
    #    print("folder '%s' cable %.1fm: results in file %d != measurements %d!" % (folder, data[i][0], len(s_ext_orig[f][i]), len(data_orig[i][1])))
    #    sys.exit(0)
    # mask external phase data as measured data above to have everything consistent
    #s_ext_orig[f] = [(lambda mask: [ex for i,ex in enumerate(s_ext_orig[f][c]) if mask[i]])(mask_pair(d[1],d[2])) for c,d in enumerate(data_orig)]
    # check again, now with masked data
    #test = [(len(d[1])!=len(s_ext_orig[f][i])) for i,d in enumerate(data)]
    #if np.any(test):
    #    i = np.arange(len(data))[test][0]
    #    print("folder '%s' cable %.1fm: results in file %d != measurements %d!" % (folder, data[i][0], len(s_ext_orig[f][i]), len(data[i][1])))
    #    sys.exit(0)

    # for the error bars we only take the statistical error and do not include the error of the offsets.
    p_delay_err[f] = np.array([np.std(r[1])/1000 for r in r0])
    if False: # include error of offsets
        p_phase_err[f] = np.sqrt(p_delay_err[f]**2 + PRIM_RT_OFF_ERR**2)*360/cycle_time
        s_phase_err[f] = np.array([np.sqrt((np.std(r[2])*360/deg_cal)**2 + (SEC_PH_OFF_ERR*360/cycle_time)**2) for r in r0])
        s_ext_err[f]   = np.array([np.max([np.std(r[3])*360/deg_cal,np.sqrt(p_phase_err[f][i]**2+s_phase_err[f][i]**2)]) for i,r in enumerate(r0)])
        s_det_err[f]   = np.array([np.max([np.std(r[4])*360/deg_cal,p_phase_err[f][i]]) for i,r in enumerate(r0)]) # this is error of fi_p
    else: # only take statistical error
        p_phase_err[f] = p_delay_err[f]*360/cycle_time
        s_phase_err[f] = np.array([np.std(r[2])*360/deg_cal for r in r0])
        #s_ext_err[f]   = np.array([np.std(r[3])*360/deg_cal for r in r0])
        s_det_err[f]   = np.array([np.std(r[4])*360/deg_cal for r in r0])

        #there is one large error bar: we have to take angle average and angle_diff to calculate standard deviation
        s_ext_err[f]   = np.array([np.sqrt(np.mean([angle_diff(ri,angle_avg_v(r[3]*360/deg_cal))**2 for ri in r[3]*360/deg_cal])) for r in r0])
        #print(s_ext_err[f]-np.array([np.std(r[3])*360/deg_cal for r in r0]))

    ##########################################################################################################
    #primary board
    ##########################################################################################################

    # steps during search [phase,t0,t1,t0_PS,t1_PS]
    # this is used for figure 6 panel a
    # t0/1 = time of leading/trailing edge of pulse measured with bus clock
    # t0/1_PS = time of leading/trailing edge of pulse meausred with phase shifted detection clock

    name = 'steps_prim_'
    files = [series+'/prim/'+folder+'/'+name+ph+'.csv' for i,ph in enumerate(label_all[f])]
    p_data[f] = [np.array(read(f,(0,1,2,3,4),[360.0/deg_cal,1,1,1,1],skip=0)) for f in files]

    #take t0_PS and t1_PS for figure 6 panel a
    p_data[f] = [[d[0],d[3],d[4]] for d in p_data[f]]

    # remove nan's
    p_data[f] = [np.transpose(np.transpose(d)[~(np.isnan(d[0]) | np.isnan(d[1]) | np.isnan(d[2]))]) for d in p_data[f]]

    # calculate primary board RT time and phases at negative jump
    # this calculation should give same result as p_delay[f] and p_phase[f] calculated by primary board. see comparison below.

    index = USE_TEST_PRIM_T0
    r0           = [np.transpose(np.transpose(r)[r[0]==index][:,1:5]) for r in result] # get all repetitions of the same measurement
    p_t0[f]      = np.array([np.mean(r[1])*cycle_time for r in r0]) # we take time_high. does not matter. you can take average of low/high or low if offset is adapted.
    p_t0_err[f]  = np.array([np.max([np.sqrt(np.sum((r[0]-r[1])**2))/(2*len(r[1])),np.std(r[1])])*cycle_time for r in r0]) # take larger of statistical vs. estimated error
    p_ph0[f]     = np.array([np.mean(r[2]+r[3])/2*360/deg_cal for r in r0]) # average phase (*)
    p_ph0_err[f] = np.array([np.max([np.sqrt(np.sum((r[2]-r[3])**2))/(2*len(r[3])),np.std(r[2]+r[3])/2])*360/deg_cal for r in r0])
    index = USE_TEST_PRIM_T1
    r1           = [np.transpose(np.transpose(r)[r[0]==index][:,1:5]) for r in result] # get all repetitions of the same measurement
    p_t1[f]      = np.array([np.mean(r[1])*cycle_time for r in r1]) # we take time_high, does not matter. you can take average of low/high or low if offset is adapted.
    p_t1_err[f]  = np.array([np.max([np.sqrt(np.sum((r[0]-r[1])**2))/(2*len(r[1])),np.std(r[1])])*cycle_time for r in r1]) # take larger of statistical vs. estimated error
    p_ph1[f]     = np.array([np.mean(r[2]+r[3])/2*360/deg_cal for r in r1]) # average phase (*)
    p_ph1_err[f] = np.array([np.max([np.sqrt(np.sum((r[2]-r[3])**2))/(2*len(r[3])),np.std(r[2]+r[3])/2])*360/deg_cal  for r in r1]) # take larger of statistical vs. estimated error
    # (*) problematic around 0 or 360 degree, board uses angle_avg function. here we check if correct for normal case.

    if correct_p_jump: #add one cycle if phase is < p_jump
        p_t0[f] = np.array([t+cycle_time if p_ph0[f][i] <= p_jump[0] else t for i,t in enumerate(p_t0[f])])
        p_t1[f] = np.array([t+cycle_time if p_ph1[f][i] <= p_jump[0] else t for i,t in enumerate(p_t1[f])])

    # primary round trip time corrected for phase
    p_RT_t0[f]       = p_t0[f] + p_ph0[f]/360*cycle_time
    p_RT_t0_err[f]   = np.sqrt(p_t0_err[f]**2 + (p_ph0_err[f]/360*cycle_time)**2)
    p_RT_t1[f]       = p_t1[f] + p_ph1[f]/360*cycle_time
    p_RT_t1_err[f]   = np.sqrt(p_t1_err[f]**2 + (p_ph1_err[f]/360*cycle_time)**2)

    # compare propagation delay calculated by board and calculated here
    # board uses integer arithmetics in ps, so the error should be order of 1e-3. 
    # actual max. error is 4e-3 for this data.
    p_prop = (p_RT_t1[f] - PRIM_RT_OFF1)/2
    p_diff = np.max(np.abs(p_delay[f] - p_prop))
    if p_diff >= 5e-3:
        print('folder %s: propagation delay error is %f! ' % (folder,p_diff))
        print('board result = ', p_delay[f])
        print('calculated   = ', p_prop)
        print('difference   = ', p_delay[f] - p_prop)
        sys.exit(0)

    # compare primary pulse phase calculated by board and calculated here
    # board saves result in phase steps, so the error should be order of 360/1120 = 0.3. 
    # actual max. error is 0.07 for this data.
    p_ph_c = ((p_prop + PRIM_RT_OFF1) % cycle_time)*360/cycle_time
    #p_diff = np.max(np.abs([angle_diff(p_phase[f][i], p_ph[i]) for i in range(len(cables[f]))])) # here we have to properly subtract phases [not needed for this data]
    p_diff = np.max(np.abs(p_phase[f] - p_ph_c))
    if p_diff >= 8e-2:
        print('folder %s: primary phase error is %f! ' % (folder,p_diff))
        print('board result = ', p_phase[f])
        print('calculated   = ', p_ph_c)
        print('difference   = ', p_phase[f] - p_ph_c)
        sys.exit(0)

    # remove short cables from fit (no short cables are in this data)
    mask = (np.array(cables[f]) >= fit_xmin)
    x = np.array(cables[f])[mask]
    # x-coordinates for fit
    x_fit = np.arange(np.min(cables[f]),np.max(cables[f]),(np.max(cables[f])-np.min(cables[f]))/1000)

    #linear fit of RT time t0 (leading edge) vs. cable length
    try:
        y = np.array(p_RT_t0[f])[mask]
        par = [0,speed] # initial offset, slope
        chi2_start = np.sum(np.power(par[0] + x*2*par[1]-y,2))
        par, cov = curve_fit((lambda x,o,v: o + x*2*v), x, y, p0 = par)
        err = np.sqrt(np.diag(cov))
        chi2_fit = np.sum(np.power(par[0] + x*2*par[1] - y,2))
        fit = np.array([cables[f],par[0] + np.array(cables[f])*2*par[1]])
        p_label_fit0    = 'fit t0 %s ns/m, offset %s ns' % (str_error(par[1],err[1]),str_error(par[0],err[0]))
        p_label_fit0_cy = 'fit t0 %s ns/m, offset %s cycles' % (str_error(par[1],err[1]),str_error(par[0]/cycle_time,err[0]/cycle_time))
        print('prim lin fit t0 speed  = %.3f %s %.3f ns/m (%s^2 = %.3f -> %.3f)' % (par[1],pm,err[1],chi,chi2_start,chi2_fit))
        print('                offset = %.3f %s %.3f ns' % (par[0],pm,err[0]))
        p_par0[f] = par
        p_err0[f] = err
        p_fit0[f] = fit
    except TypeError:
        print("TypeError: fit RT time t0")

    #linear fit of RT time t1 (trailing edge) vs. cable length
    try:
        y = np.array(p_RT_t1[f])[mask]
        par = [0,speed] # initial offset, slope
        chi2_start = np.sum(np.power(par[0] + x*2*par[1]-y,2))
        par, cov = curve_fit((lambda x,o,v: o + x*2*v), x, y, p0 = par)
        err = np.sqrt(np.diag(cov))
        chi2_fit = np.sum(np.power(par[0] + x*2*par[1] - y,2))
        fit = np.array([cables[f],par[0] + np.array(cables[f])*2*par[1]])
        p_label_fit1    = 'fit t0 %s ns/m, offset %s ns' % (str_error(par[1],err[1]),str_error(par[0],err[0]))
        p_label_fit1_cy = 'fit t0 %s ns/m, offset %s cycles' % (str_error(par[1],err[1]),str_error(par[0]/cycle_time,err[0]/cycle_time))
        print('prim lin fit t1 speed  = %.3f %s %.3f ns/m (%s^2 = %.3f -> %.3f)' % (par[1],pm,err[1],chi,chi2_start,chi2_fit))
        print('                offset = %.3f %s %.3f ns' % (par[0],pm,err[0]))
        p_par1[f] = par
        p_err1[f] = err
        p_fit1[f] = fit
    except TypeError:
        print("TypeError: fit RT time t1")

    ##########################################################################################################
    #secondary board
    ##########################################################################################################

    # steps during search [phase,t0,t1,t0_PS,t1_PS]
    # this data is not shown
    # t0/1 = time of leading/trailing edge of pulse measured with bus clock
    # t0/1_PS = time of leading/trailing edge of pulse meausred with phase shifted detection clock

    name = 'steps_sec_'
    files = [series+'/sec/'+folder+'/'+name+ph+'.csv' for i,ph in enumerate(label_all[f])]
    s_data = [None for f in files]
    for i,fd in enumerate(files):
        try:
            s_data[i] = np.array(read(fd,(0,1,2,3,4),[360.0/deg_cal,1,1,1,1],skip=0))
        except Exception as e:
            print("file '%s' error '%s'" % (fd,str(e)))
            sys.exit(1)

    #take difference t0_PS - t0 and t1_PS - t1
    s_data = [[d[0],d[3]-d[1],d[4]-d[2]] for d in s_data]

    # remove nan's
    s_data = [np.transpose(np.transpose(d)[~(np.isnan(d[0]) | np.isnan(d[1]) | np.isnan(d[2]))]) for d in s_data]

    # calculate secondary board RT time and phases at negative jump
    # this calculation should give same result as p_delay[f] calculated by primary board. see comparison below.
    index = USE_TEST_SEC_T0
    r0        = [np.transpose(np.transpose(r)[r[0]==index][:,1:5]) for r in result]
    s_t0[f]      = np.array([np.mean(r[0]+r[1]-19)*cycle_time/2 for r in r0])
    s_t0_err[f]  = np.array([np.max([np.sqrt(np.sum((r[0]-r[1])**2))/(2*len(r[1])),np.std(r[0]+r[1])/2])  for r in r0])
    s_ph0[f]     = np.array([np.mean(r[2]+r[3])/2*360/deg_cal for r in r0])
    s_ph0_err[f] = np.array([np.max([np.sqrt(np.sum((r[2]-r[3])**2))/(2*len(r[3])),np.std(r[2]+r[3])/2])*360/deg_cal  for r in r0])
    index = USE_TEST_SEC_T1
    r1        = [np.transpose(np.transpose(r)[r[0]==index][:,1:5]) for r in result]
    s_t1[f]      = np.array([np.mean(r[0]+r[1]-19)*cycle_time/2 for r in r1])
    s_t1_err[f]  = np.array([np.max([np.sqrt(np.sum((r[0]-r[1])**2))/(2*len(r[1])),np.std(r[0]+r[1])/2])  for r in r1])
    s_ph1[f]     = np.array([np.mean(r[2]+r[3])/2*360/deg_cal for r in r1])
    s_ph1_err[f] = np.array([np.max([np.sqrt(np.sum((r[2]-r[3])**2))/(2*len(r[3])),np.std(r[2]+r[3])/2])*360/deg_cal  for r in r1])

    if correct_s_jump: #add one cycle if phase is < s_jump [not needed here, we just use the phase]
        s_t0[f] = np.array([t+cycle_time if s_ph0[i] <= s_jump[0] else t for i,t in enumerate(s_t0[f])])
        s_t1[f] = np.array([t+cycle_time if s_ph1[i] <= s_jump[0] else t for i,t in enumerate(s_t1[f])])

    # convert to numpy array for applying mask
    cables[f] = np.array(cables[f])

    # calculate external PLL and detector phase and if have to add 1 cycle for waiting time
    [s_ext_c,s_det_c,wait] = np.transpose([get_ext_det_phase(p_phase[f][i],s_phase[f][i],folder+'/'+str(cables[f][i])+'m') for i in range(len(cables[f]))])

    # compare secondary pulse phase calculated by board and calculated here
    # board saves result in phase steps, so the error per measurement should be order of 360/1120 = 0.3. 
    # but we compare the averaged result over at least 5 measurements which gives a somewhat larger error.
    s_ph_c = s_ph0[f] - SEC_PH_OFF0*360/cycle_time; # SEC_PH_OFF0 is in ns
    s_diff = [angle_diff(s_phase[f][i], s_ph_c[i]) for i in range(len(cables[f]))] # here we have to properly subtract phases
    if np.max(np.abs(s_diff)) >= 1.1:
        print('folder %s: secondary pulse phase error is %f! ' % (folder,np.max(np.abs(s_diff))))
        print('board result = ', s_phase[f])
        print('calculated   = ', s_ph_c)
        print('difference   = ', s_diff)
        i = np.arange(len(cables[f]))[np.abs(s_diff)==np.max(np.abs(s_diff))]
        print('cable %dm:\nboard p_ph=%.3f, s_ph=%.3f, p_det=%.3f, p_ext=%.3f\ncalc  p_ph=%.3f, s_ph=%.3f, p_det=%.3f, p_ext=%.3f' % (cables[f][i], 
            p_phase[f][i], s_phase[f][i], s_det[f][i], s_ext[f][i], p_ph_c[i], s_ph_c[i], s_det_c[i], s_ext_c[i]))
        sys.exit(0)

    # compare detector phase calculated by board and calculated here
    # board saves result in phase steps, so the error per measurement should be order of 360/1120 = 0.3. 
    # but we compare the averaged result over at least 5 measurements which gives a somewhat larger error.
    s_diff = [angle_diff(s_det[f][i], s_det_c[i]) for i in range(len(cables[f]))] # here we have to properly subtract phases
    if np.max(np.abs(s_diff)) >= 0.8:
        print('folder %s: detector phase error is %f! ' % (folder,np.max(np.abs(s_diff))))
        print('board result = ', s_det[f])
        print('calculated   = ', s_det_c)
        print('difference   = ', s_diff)
        i = np.arange(len(cables[f]))[np.abs(s_diff)==np.max(np.abs(s_diff))]
        print('cable %dm:\nboard p_ph=%.3f, s_ph=%.3f, p_det=%.3f, p_ext=%.3f\ncalc  p_ph=%.3f, s_ph=%.3f, p_det=%.3f, p_ext=%.3f' % (cables[f][i], 
            p_phase[f][i], s_phase[f][i], s_det[f][i], s_ext[f][i], p_ph_c[i], s_ph_c[i], s_det_c[i], s_ext_c[i]))
        sys.exit(0)

    # compare secondary external PLL phase calculated by board and calculated here
    # board saves result in phase steps, so the error per measurement should be order of 360/1120 = 0.3. 
    # but we compare the averaged result over at least 5 measurements which gives a somewhat larger error.
    s_diff = [angle_diff(s_ext[f][i], s_ext_c[i]) for i in range(len(cables[f]))] # here we have to properly subtract phases
    if np.max(np.abs(s_diff)) >= 0.6:
        print('folder %s: external PLL phase error is %f! ' % (folder,np.max(np.abs(s_diff))))
        print('board result = ', s_ext[f])
        print('calculated   = ', s_ext_c)
        print('difference   = ', s_diff)
        i = np.arange(len(cables[f]))[np.abs(s_diff)==np.max(np.abs(s_diff))]
        print('cable %dm:\nboard p_ph=%.3f, s_ph=%.3f, p_det=%.3f, p_ext=%.3f\ncalc  p_ph=%.3f, s_ph=%.3f, p_det=%.3f, p_ext=%.3f' % (cables[f][i], 
            p_phase[f][i], s_phase[f][i], s_det[f][i], s_ext[f][i], p_ph_c[i], s_ph_c[i], s_det_c[i], s_ext_c[i]))
        sys.exit(0)

    #linear fit of secondary phase vs. cable length leading edge (t0)
    try:
        y  = s_phase[f]*cycle_time/360 # fit in ns
        # add cycle_time steps as we expect it to get a linear relation
        y = y + [(l*speed // cycle_time)*cycle_time for l in cables[f]]
        # starting values [offset, propagation delay]
        par = [0, speed]
        chi2_start = np.sum(np.power(par[0] + x*par[1] - y,2))
        par, cov = curve_fit((lambda x,o,v: o + x*v), x, y, p0 = par)
        err = np.sqrt(np.diag(cov))
        chi2_fit = np.sum(np.power(par[0] + x*par[1] - y,2))
        fit = np.array([x_fit,((par[0] + x_fit*par[1]) % cycle_time)*360/cycle_time]) # model function in degrees
        #fit = np.array([x_fit,(par[0] + x_fit*par[1])])
        s_label_fit_mean    = 'fit <t> %s ns/m, offset %s ns' % (str_error(par[1],err[1]),str_error(par[0],err[0]))
        s_label_fit_mean_cy = 'fit <t> %s ns/m, offset %s cycles' % (str_error(par[1],err[1]),str_error(par[0]/cycle_time,err[0]/cycle_time))
        print('sec fit s_phase t0 prop. delay  = %.3f %s %.3f ns/m (%s^2 = %.3f -> %.3f)' % (par[1],pm,err[1],chi,chi2_start,chi2_fit))
        print('                         offset = %.3f %s %.3f ns' % (par[0],pm,err[0]))
        s_par0[f] = par
        s_err0[f] = err
        s_fit0[f] = fit
    except TypeError:
        print("TypeError: fit secondary phase")

    #linear fit of secondary phase vs. cable length trailing edge (t1)
    try:
        y = s_ph1[f] - SEC_PH_OFF1*360/cycle_time
        y  = y*cycle_time/360 # fit in ns
        # add cycle_time steps as we expect it to get a linear relation
        y = y + [(l*speed // cycle_time)*cycle_time for l in cables[f]]
        # starting values [offset, propagation delay]
        par = [0, speed]
        chi2_start = np.sum(np.power(par[0] + x*par[1] - y,2))
        par, cov = curve_fit((lambda x,o,v: o + x*v), x, y, p0 = par)
        err = np.sqrt(np.diag(cov))
        chi2_fit = np.sum(np.power(par[0] + x*par[1] - y,2))
        fit = np.array([x_fit,((par[0] + x_fit*par[1]) % cycle_time)*360/cycle_time]) # model function in degrees
        #fit = np.array([x_fit,(par[0] + x_fit*par[1])])
        s_label_fit_mean    = 'fit <t> %s ns/m, offset %s ns' % (str_error(par[1],err[1]),str_error(par[0],err[0]))
        s_label_fit_mean_cy = 'fit <t> %s ns/m, offset %s cycles' % (str_error(par[1],err[1]),str_error(par[0]/cycle_time,err[0]/cycle_time))
        print('sec fit s_phase t1 prop. delay  = %.3f %s %.3f ns/m (%s^2 = %.3f -> %.3f)' % (par[1],pm,err[1],chi,chi2_start,chi2_fit))
        print('                         offset = %.3f %s %.3f ns' % (par[0],pm,err[0]))
        s_par1[f] = par
        s_err1[f] = err
        s_fit1[f] = fit
    except TypeError:
        print("TypeError: fit secondary phase")

# list of all cable lengths (the hstack allows flattening of non-uniform sub-array lengths)
# we use labels for distinction which allows to have same cables length but different data points
labels_all = np.unique(np.hstack(label_all))
cables_all = [cables[0][np.array(label_all[0])==l][0] for l in labels_all]

##########################################################################################################
# figure 6 panel a
##########################################################################################################

#plot selected jumps
folder = f_sel # show data for this folder
try:
    f = np.arange(len(folders))[np.array(folders)==folder][0] # folder index
except IndexError:
    print('jumps (jump_0/1) IndexError: check folder \'%s\'' % (folder))
    sys.exit(0)
if len(sel) == 0:
    mask = [True]*len(cables[f])
else:
    mask = [np.any(np.array(sel)==c) for c in label_all[f]]
i_sel = np.arange(len(cables[f]))[mask] # index of selected cables out of cables[f]
print('panel (a) N_RT[0] = ',[p_data[f][i][1][0] for i in i_sel])
#we use primary board data (p_data)
#data is for pulse leading edge = 0, pulse trailing edge = 1
#we split into two panels to break y-axis: top panel = t, bottom panel = b
po_jump_0 = [[]]*len(i_sel)
po_jump_1 = [[]]*len(i_sel)
po_jump_0b = po_jump_0[0:2]
po_jump_0t = po_jump_0[2:]
po_jump_1b = po_jump_1[0:2]
po_jump_1t = po_jump_1[2:]
li_jump_0 = [np.transpose([(p_data[f][i][0]%360)+xoff,p_data[f][i][1]+yoff*j]) for j,i in enumerate(i_sel)]
li_jump_0 = [np.transpose(d[d[:,0].argsort()]) for d in li_jump_0] # sort by phase
li_jump_1 = [np.transpose([(p_data[f][i][0]%360)+xoff,p_data[f][i][2]+yoff*j]) for j,i in enumerate(i_sel)]
li_jump_1 = [np.transpose(d[d[:,0].argsort()]) for d in li_jump_1] # sort by phase
li_jump_0b = li_jump_0[0:2]
li_jump_0t = li_jump_0[2:]
li_jump_1b = li_jump_1[0:2]
li_jump_1t = li_jump_1[2:]
la_jump = np.array(label_all[f])[mask].tolist()
la_jump_b = la_jump[0:2]
la_jump_t = la_jump[2:]
sh_jump = [[]]*len(i_sel)
sc_jump = [1]*len(i_sel)
co_jump   = [colors(i) for i in range(len(i_sel))]
co_jump_b = co_jump[0:2]
co_jump_t = co_jump[2:]
da_jump = [{'s':10}]*len(i_sel)
ma_jump = [{'linestyle':'solid', 'linewidth':2}]*len(i_sel)
#plot(None, 'jump_0', po_jump_0, la_jump, li_jump_0, sh_jump, sc_jump, co_jump, da_jump, ma_jump)
#plot(None, 'jump_1', po_jump_1, la_jump, li_jump_1, sh_jump, sc_jump, co_jump, da_jump, ma_jump)

if False: # fit \phi_+ = 25(1) degree
    xrng = [10,40] # phase range where jump should be. initial value = center. 
    x0_all = [[None]*2]*len(folders)
    sigma_all = [[None]*2]*len(folders)
    for f in range(len(folders)):
        for t in (0,1):
            # p_data[folder][cable][{phase,t0,t1}][value]
            jumps = [np.transpose([(p_data[f][i][0]%360),p_data[f][i][1+t]]) for i in range(len(cables[f]))]
            jumps = [np.transpose(d[d[:,0].argsort()]) for d in jumps] # sort by phase
            jumps = [np.transpose(np.transpose(d)[(d[0]>=xrng[0]) & (d[0]<=xrng[1])]) for d in jumps] # select phases within xrng   
            # fit all jumps
            result = [find_jump(d[0],d[1]) for d in jumps]
            [x0, sigma, x0_err, sigma_err, y_low, y_high, ok] = np.transpose([r[0] for r in result])
            fit = [r[1] for r in result]
            ok = [o==1 for o in ok]
            num = len(cables[f])
            plot(None, 'jumps', 
                    [[[x0[i]],[y_high[i]+0.2],[sigma[i]],[0]] if ok[i] else [] for i in range(num)]+[[]]*num, 
                    cables[f].tolist()+[None]*num+['observed jumps in t%i for ext clock %.1f' % (t, ext_clk[f])], 
                    jumps + [[f[0],f[1]+y_high[i]+0.2] if ok[i] else [] for i,f in enumerate(fit)], 
                    [[]]*2*num, 
                    [1]*2*num, 
                    [colors(i % clen) for i in range(num)]*2, 
                    [{'s':50}]*2*num, 
                    [{'linestyle':'solid', 'linewidth':2}]*2*num)
            x0_all[f][t] = x0
            sigma_all[f][t] = sigma
    # flatten flatten all data
    x0_all = [t for f in x0_all for t in f]        
    sigma_all = [t for f in sigma_all for t in f]

    # get mean and standard deviation
    x0_mean = np.mean(x0_all)
    x0_std  = np.std(x0_all)
    sigma_mean = np.mean(sigma_all)
    sigma_std  = np.std(sigma_all)

    # this is the result of all data for t0 and t1
    print('positive jump mean phase = %s degree, sigma = %s degree'%(str_error(x0_mean,x0_std),str_error(sigma_mean,sigma_std)))

    # get mean and standard deviation with weights = sigma (there are a few broader ones)
    x0_mean = np.average(x0_all, weights=sigma_all)
    x0_std  = np.sqrt(np.average((x0_all-x0_mean)**2, weights=sigma_all))

    # this is the result of all data for t0 and t1
    print('positive jump mean phase = %s degree (weighted with sigma)'%(str_error(x0_mean,x0_std)))

    # plot all 4x2 = 8 figures
    plt.show()

    # exit here
    sys.exit()

##########################################################################################################
#figure 6 panel b
##########################################################################################################

# t1 RT time vs. cable length

# compare mean primary and secondary propagation delay per unit length for leading (t0) and trailing (t1) edge
slope_y  = [p_par0,p_par1,s_par0,s_par1]
slope_dy = [p_err0,p_err1,s_err0,s_err1]
slope_label = ['prim t0','prim t1','sec  t0','sec  t1']
slope_result = [0]*len(slope_y)
for i in range(len(slope_y)):
    y = np.array(slope_y[i])[:,1]
    dy = np.array(slope_dy[i])[:,1]
    dy = max(np.std(y),np.mean(dy))
    y = np.mean(y)
    print(('%s   propagation delay/m = %.3f '+pm+' %.3f ns/m') % (slope_label[i], y, dy)) 
    slope_result[i] = [y,dy]
y  = [slope_result[0][0],slope_result[1][0]]
dy = [slope_result[0][1],slope_result[1][1]]
dy = max(np.std(y),np.mean(dy))
y  = np.mean(y)
print(('prim avg. propagation delay/m = %.3f '+pm+' %.3f ns/m') % (y, dy)) 
# save primary average for figure 5 panel b
prim_slope = r'$\frac{d \tau_p}{dL}$ = %s ns/m' % (str_error(np.mean(y),dy))

y  = [slope_result[2][0],slope_result[3][0]]
dy = [slope_result[2][1],slope_result[3][1]]
dy = max(np.std(y),np.mean(dy))
y  = np.mean(y)
print(('sec  avg. propagation delay/m = %.3f '+pm+' %.3f ns/m') % (y, dy)) 
# save secondary average for figure 6
sec_slope = r'$\frac{d \tau_p}{dL}$ = %s ns/m' % (str_error(np.mean(y),dy))

# compare with expected propagation delay from RG58 (Tasker) cable datasheet
print('prim. mean propagation delay %s (c.f. %.3f ns/m RG58)' % (prim_slope,speed)) 

# select folder to show
folder = f_sel
try:
    f = np.arange(len(folders))[np.array(folders)==folder][0] # folder index
except IndexError:
    print('mean propagation time vs. cable length (t_RT) IndexError: check folder \'%s\'' % (folder))
    sys.exit(0)
if True: # plot board result on top (we check above that they are the same)
    la_RT = [prim_slope, 'board result']
    po_RT = [[cables[f],p_RT_t1[f],p_RT_t1_err[f]],[cables[f],p_delay[f]*2+PRIM_RT_OFF1,p_delay_err[f]*2]]
    li_RT = [[x,x*2*p_par1[f][1] + p_par1[f][0]],[]]
else: # plot only one result
    la_RT = [prim_slope]
    po_RT = [[cables[f],p_RT_t1[f],p_RT_t1_err[f]]]
    li_RT = [[x,x*2*p_par1[f][1] + p_par1[f][0]]]
co_RT = [colors(4),colors(5)]
sh_RT = [[]]*2
sc_RT = [1]*2
da_RT = [{'s':50},{'s':20}]
ma_RT = [{'linestyle':'solid', 'linewidth':2},{'linestyle':'dashed', 'linewidth':2}]

#plot(None, 't_RT', po_RT, la_RT, li_RT, sh_RT, sc_RT, co_RT, da_RT, ma_RT)

##########################################################################################################
# figure 6 panel c
##########################################################################################################

# synchronisation error vs. cable length all external clocks combined
# combine data
sync_error_all     = [np.hstack([np.array(sync_error[f])[np.array(label_all[f]) == c] for f in range(len(folders))]) for c in labels_all]
sync_error_err_all = [np.std(e) for e in sync_error_all]
sync_error_all     = [np.mean(e) for e in sync_error_all]
# get mean and standard deviation
y = np.array(sync_error_all)
mean = np.mean(y)
std = np.std(y)
label_scope = r'error = (%.1f $\pm$ %.1f) ns' % (mean,std)
la_sync_error = [label_scope]
po_sync_error = [[cables_all,sync_error_all,sync_error_err_all]]
li_sync_error = [[]]*2
sh_sync_error = [[[10,31.3],[mean-std,mean-std],[mean+std,mean+std]],[]]
sc_sync_error = [1]*2
co_sync_error = [colors(6)]
da_sync_error = [{'s':50}]
ma_sync_error = [{'linestyle':'solid', 'linewidth':2}]*2

print('synchronization %s (manual measured result on scope)' % label_scope)
#plot(None, 'sync_error', po_sync_error, la_sync_error, li_sync_error, sh_sync_error, sc_sync_error, co_sync_error, da_sync_error, ma_sync_error)

##########################################################################################################
# figure 6 insert
##########################################################################################################

# use arctan (True) or smooth step (False) for fitting
use_arctan = False

if False: # plot a single or few traces with fit result
    i = [120,135,140,150] # list of trace numbers big error at: 80-95,140-150. small error at: 120,135
    num = len(i)
    t = [read(tr_folder+('SDS%05i.csv'%ii),(0,1,2,3,4),[1e9,10,10,10,10],skip=2) for ii in i]
    prim = [[ti[0],ti[3]] for ti in t]
    sec  = [[ti[0],ti[4]] for ti in t]
    if use_arctan: # use arctan
        pfit = arctan
        ffit = get_offset_arctan
    else:          # use smooth slope
        pfit = smooth_slope
        ffit = get_offset_slope
    p_par, p_err = np.transpose([ffit(pi[0],pi[1]) for pi in prim],axes=[1,0,2])
    s_par, s_err = np.transpose([ffit(si[0],si[1]) for si in sec],axes=[1,0,2])
    if True: # print result
        for ii,index in enumerate(i):
            p_x0,p_slope,p_an,p_ap,p_sig = p_par[ii]
            s_x0,s_slope,s_an,s_ap,s_sig = s_par[ii]
            p_chi2 = np.sum((pfit(prim[ii][0], *p_par[ii]) - prim[ii][1])**2)
            s_chi2 = np.sum((pfit(sec [ii][0], *s_par[ii]) - sec [ii][1])**2)
            print('%3i: prim fit result [x0,sigma,y-,y+] = [%.3f,%.3f,%.3f,%.3f,%.3f]'%(index,p_x0,p_slope,p_an,p_ap,p_sig))
            print('              error                   = [%.3f,%.3f,%.3f,%.3f,%.3f]'%(p_err[ii][0],p_err[ii][1],p_err[ii][2],p_err[ii][3],p_err[ii][4]))
            print('              chi^2                   = %.3f' % (p_chi2))
            print('%3i: sec  fit result [x0,sigma,y-,y+] = [%.3f,%.3f,%.3f,%.3f,%.3f]'%(index,s_x0,s_slope,s_an,s_ap,s_sig))
            print('              error                   = [%.3f,%.3f,%.3f,%.3f,%.3f]'%(s_err[ii][0],s_err[ii][1],s_err[ii][2],s_err[ii][3],s_err[ii][4]))
            print('              chi^2                   = %.3f' % (s_chi2))
            print(('%3i: sync error = x0(sec) - x0(prim)  = %.3f '+pm+' %.3f\n') % (index, s_x0 - p_x0, np.sqrt(p_err[ii][0]**2 + s_err[ii][0]**2)))
    #x coordinate for plot
    if False: x = prim[0][0]
    else:     x = np.arange(prim[0][0][0]-2,prim[0][0][-1]+2,0.1)
    if True: # offset all traces for secondary trace at 0
        for ii in range(num):
            offset = -s_par[ii][0]
            prim[ii][0]  = prim[ii][0] + offset
            sec[ii][0]   = sec[ii][0]  + offset
            p_par[ii][0] = p_par[ii][0] + offset
            s_par[ii][0] = s_par[ii][0] + offset
    plot(None, 'trace', prim + sec, ['prim']+[None]*(num-1) + ['sec']+[None]*(num-1), [[x,pfit(x,*p_par[ii])] for ii in range(num)] + [[x,pfit(x,*s_par[ii])] for ii in range(num)], 
            [[]]*num*2, [1]*num*2, [colors(0)]*num + [colors(2)]*num, [{'s':50}]*num*2, [{'linestyle':'solid', 'linewidth':2}]*num*2)
    plt.show()
    sys.exit(0)

# traces
# combine trace index [folder,cable,measurement] to [cable,measurement]
#s_ext_orig = [np.concatenate([s_ext_orig[f][i]       for f in range(len(trace_i)) for i in range(len(trace_i[f])) if (cables[f][i]==c)]) for c in cables_all]
#trace_f    = [np.concatenate([[f]*len(trace_i[f][i]) for f in range(len(trace_i)) for i in range(len(trace_i[f])) if (cables[f][i]==c)]) for c in cables_all]
#trace_i    = [np.concatenate([trace_i[f][i]          for f in range(len(trace_i)) for i in range(len(trace_i[f])) if (cables[f][i]==c)]) for c in cables_all]
#for i,t in enumerate(trace_i): print("cabe %s: %d (%d) measurements: [%i..%i], %s" % (labels_all[i],len(t),len(trace_f[i]),t[0],t[-1],trace_f[i]))
# list all traces from primary and secondary boards
#tr_names = [f for f in glob.glob(tr_folder+'*.csv')]
#tr_names = [tr_folder+('SDS%05i.csv'%i) for tc in trace_i for i in tc]
tr_err  = [[None]*len(cables[f]) for f in range(len(folders))]
tr_prim = [[None]*len(cables[f]) for f in range(len(folders))]
tr_sec  = [[None]*len(cables[f]) for f in range(len(folders))]
tr_off  = [[None]*len(cables[f]) for f in range(len(folders))]
#tr_corr = [[[],[],[],[]]]*len(ext_clk) # correlation of external clock with sync error [x,y,dx,dy]
for f in range(len(folders)):
    for i,tc in enumerate(trace_i[f]):
        # read all traces for given [folder,cable length]
        traces = [np.array(read(tr_folder+('SDS%05i.csv'%ii),(0,1,2,3,4),[1e9,10,10,10,10],skip=2)) for ii in tc]
        tr_prim[f][i] = [[t[0],t[3]] for t in traces]
        tr_sec [f][i] = [[t[0],t[4]] for t in traces]

        # fit offset of primary and secondary boards
        if use_arctan: # use arctan
            p_par, p_err = np.transpose([get_offset_arctan(t[0],t[1]) for t in tr_prim[f][i]],axes=[1,2,0])
            s_par, s_err = np.transpose([get_offset_arctan(t[0],t[1]) for t in tr_sec [f][i]],axes=[1,2,0])
        else: # use smooth step function
            p_par, p_err = np.transpose([get_offset_slope(t[0],t[1]) for t in tr_prim[f][i]],axes=[1,2,0])
            s_par, s_err = np.transpose([get_offset_slope(t[0],t[1]) for t in tr_sec[ f][i]],axes=[1,2,0])

        #p_off[i]  = p_par[0]
        #p_off_err = p_err[0]
        #s_off[i]  = s_par[0]
        #s_off_err = s_err[0]

        # auto-sync error = offset sec - offset prim
        # we save [cable, mean error, std error, set ext_clk, set ext_clk + measured ext_clk, error of measured ext_clk]
        tr_err[f][i] = np.array([cables[f][i], np.mean(s_par[0] - p_par[0]), np.std(s_par[0]-p_par[0]), ext_clk[f], map_360(ext_clk[f]+s_ext[f][i]), s_ext_err[f][i]])

        # offset traces by s_off
        tr_off[f][i] = s_par[0]

        # error for [folder,measurement] used for correlation plot with fi_ext [x,y,dx,dy]
        #for f,ex in enumerate(ext_clk):  
        #    tr_corr[f][0] = tr_corr[f][0] + (np.array([map_360(ex+e) for e in s_ext_orig[i]])[trace_f[i]==f]).tolist()
        #    tr_corr[f][1] = tr_corr[f][1] + ((s_par[0] - p_par[0])[trace_f[i]==f]).tolist()
        #    tr_corr[f][2] = tr_corr[f][2] + [np.std(s_ext_err[f])]*len(s_off[i][trace_f[i]==f]) # estimate single point error from average error
        #    tr_corr[f][3] = tr_corr[f][3] + ((np.sqrt(s_off_err**2 + p_off_err**2))[trace_f[i]==f]).tolist()


# [list of cables,list of sync_errors,list of sync_error_errs, list of set ext_clk, list of measured s_ext]
tr_err_all = np.transpose([dc for df in tr_err for dc in df])
print(tr_err_all.shape)

# [list of cables, list of <sync_error>, list of <sync_error>_err]
tr_err = np.transpose([[c,np.mean(tr_err_all[1][tr_err_all[0]==c]),np.std(tr_err_all[1][tr_err_all[0]==c])] for c in cables_all])

# list of [list of ext_clk+s_ext, list of <sync_error>, list of s_ext_err, list of <sync_error>_err] for each ext_clk
tr_corr = [[tr_err_all[4][tr_err_all[3]==ex], tr_err_all[1][tr_err_all[3]==ex], tr_err_all[5][tr_err_all[3]==ex], tr_err_all[2][tr_err_all[3]==ex]] for ex in ext_clk]

# flatten traces for inset
tr_prim  = [dm for df in tr_prim for dc in df for dm in dc]
tr_sec   = [dm for df in tr_sec  for dc in df for dm in dc]
tr_off   = [dm for df in tr_off  for dc in df for dm in dc]
num = len(tr_prim)

# mean and standard synchronization error of all traces
tr_mean  = np.mean(tr_err[1])
tr_std   = np.std (tr_err[1])
tr_label = r'error = (%.1f $\pm$ %.1f) ns' % (tr_mean,tr_std)

# offset both traces to have secondary trace at 0. this corrects trigger errors of oscilloscope.
tr_prim = [[t[0]-tr_off[i],t[1]] for i,t in enumerate(tr_prim)]
tr_sec  = [[t[0]-tr_off[i],t[1]] for i,t in enumerate(tr_sec)]
la_tr = ['prim'] + [None]*(num-1) + ['sec'] + [None]*(num-1) + [tr_label]
po_tr = [[]]*(2*num+1)
li_tr = tr_prim + tr_sec + [[]]
sh_tr = [[]]*2*num + [[[tr_mean-tr_std,tr_mean+tr_std],[-1,-1],[5,5]]]
sc_tr = [1]*(2*num+1)
co_tr = [colors(0)]*num + [colors(2)]*num + [colors(6)]
da_tr = [{'s':50}]*(2*num+1)
ma_tr = [{'linestyle':'solid', 'linewidth':2}]*(2*num+1)

if use_err_fit: # replace manually measured with fitted synchronization error
    po_sync_error = [[tr_err[0],tr_err[1],tr_err[2]]]
    la_sync_error = [tr_label]
    sh_sync_error = [[[10,31.3],[tr_mean-tr_std,tr_mean-tr_std],[tr_mean+tr_std,tr_mean+tr_std]],[]]

if False: # add fitted synchronization error as small brighter dot (set use_err_fit=False. same result but slightly shifted)
    po_sync_error = po_sync_error + [[tr_err[0],tr_err[1],tr_err[2]]]
    la_sync_error = la_sync_error + ['fit']
    co_sync_error = co_sync_error + [colors(7)]
    da_sync_error = da_sync_error + [{'s':20}]
else: # add same data as small brighter dot in center (just for fun). same as setting 'edgecolors':color but then error bar color is inner color and not edge color
    po_sync_error = po_sync_error + [[po_sync_error[0][0],po_sync_error[0][1],[0]*len(po_sync_error[0][0])]]
    la_sync_error = la_sync_error + ['fit']
    co_sync_error = co_sync_error + [colors(7)]
    da_sync_error = da_sync_error + [{'s':20}]

print('synchronization %s (fitted result on %d traces)' % (tr_label, num))

#plot(None, 'traces', po_tr, la_tr, li_tr, sh_tr, sc_tr, co_tr, da_tr, ma_tr)

##########################################################################################################
# figure 6 panels a-c and insert
##########################################################################################################
# for panel a we select here jump_0=leading edge or jump_1=trailing edge to be displayed
# t = top part of jumps panel (a)

if True:
    panel(
        [po_jump_0t,po_jump_0,po_RT,po_sync_error,po_tr], 
        [la_jump_t ,la_jump  ,la_RT,la_sync_error,la_tr], 
        [li_jump_0t,li_jump_0,li_RT,li_sync_error,li_tr], 
        [sh_jump   ,sh_jump  ,sh_RT,sh_sync_error,sh_tr], 
        [sc_jump   ,sc_jump  ,sc_RT,sc_sync_error,sc_tr], 
        [co_jump_t ,co_jump  ,co_RT,co_sync_error,co_tr], 
        [da_jump   ,da_jump  ,da_RT,da_sync_error,da_tr], 
        [ma_jump   ,ma_jump  ,ma_RT,ma_sync_error,ma_tr])

##########################################################################################################
# figure 8 panel a
##########################################################################################################

# primary and secondary pulse phase and difference vs. cable length for selected data
folder = f_sel # show data for this folder
try:
    f = np.arange(len(folders))[np.array(folders)==folder][0] # folder index
except IndexError:
    print('prim & sec pulse phase vs. cable length (phase) IndexError: check folder \'%s\'' % (folder))
    sys.exit(0)
# generate lines without jumps linear fit of secondary pulse phase vs. cable length % cycle_time
# the s_phase was calculated from t0
par = s_par0[f]
x = np.array([(0/360*cycle_time-par[0])/par[1],(cycle_time-par[0])/par[1]])
fit = [[x+o*cycle_time/par[1],(par[0]+x*par[1])*360/cycle_time] for o in range(2,9)]
la_phase = [r'$\varphi_{p}$',r'$\varphi_{s}$',r'$\varphi_{ext}$',sec_slope]+['']*len(fit)
# these are measured phases by boards, p=primary, s=secondary
po_phase = [  [cables[f],p_phase[f],p_phase_err[f]],
              [cables[f],s_phase[f],s_phase_err[f]],
              [cables[f],s_ext[f],s_ext_err[f]],
              []
            ] + [[]]*len(fit)
li_phase = [[],[],[],[]] + fit
sh_phase = [[[cables[f][0]-0.35,cables[f][-1]+0.35],[160,160],[200,200]]] + [[]]*(3+len(fit))
sc_phase = [1]*(4+len(fit))
co_phase   = [colors(4),colors(0),colors(2),'Black']+[colors(0)]*len(fit)
da_phase = [{'s':60,'marker':'o','facecolors':'white'},{'s':50,'marker':'s','facecolors':'white'},{'s':50,'marker':'D','facecolors':'white'}] + [{'s':20}]*(1+len(fit))
ma_phase = [{'linestyle':'solid', 'linewidth':2}]*3 + [{'linestyle':'dotted', 'linewidth':2}] + [{'linestyle':'dashed', 'linewidth':2}]*len(fit)

#plot(None, 'phase', po_phase, la_phase, li_phase, sh_phase, sc_phase, co_phase, da_phase, ma_phase)

print('mean fi_ext = %s for folder %s' % (str_error(np.mean(s_ext[f]),np.std(s_ext[f])), folder))

##########################################################################################################
# figure 8 panel b
##########################################################################################################

if use_err_fit: # fitted error
    po_corr = tr_corr
else: # manually measured error with scope
    po_corr = [[[map_360(ex+e) for e in s_ext[f]],sync_error[f],s_ext_err[f],sync_error_err[f]] for f,ex in enumerate(ext_clk)]

x = np.array([di for d in po_corr for di in d[0]])
y = np.array([di for d in po_corr for di in d[1]])
par = [0,cycle_time/360] # initial offset, slope
chi2_start = np.sum(np.power(par[0] + x*par[1]-y,2))
par, cov = curve_fit((lambda x,o,k: o + x*k), x, y, p0 = par)
err = np.sqrt(np.diag(cov))
chi2_fit = np.sum(np.power(par[0] + x*par[1] - y,2))
x = np.array([220-3,290+3])
fit = np.array([x,par[0] + x*par[1]])
p_label_fit1    = 'fit corr %s ns/degree, offset %s ns' % (str_error(par[1],err[1]),str_error(par[0],err[0]))
print('fit corr slope  = %.3f %s %.3f ns/degree (%s^2 = %.3f -> %.3f)' % (par[1],pm,err[1],chi,chi2_start,chi2_fit))
print('         offset = %.3f %s %.3f ns' % (par[0],pm,err[0]))
print('         offset = %.3f %s %.3f degree' % (-par[0]/par[1],pm,par[0]/par[1]*np.sqrt((err[0]/par[0])**2+(err[1]/par[1])**2)))

# correlation of synchronization error vs. 270-delta_tau_c*2\pi/T
la_corr = [r'%d$^{\circ}$'%ex for ex in ext_clk]
li_corr = [[],fit,[],[]]
sh_corr = [[]]*4
sc_corr = [1]*4
co_corr = [colors(0),colors(2),colors(4),colors(6)]
da_corr = [{'s':50}]*4
ma_corr = [{'linestyle':'dashed', 'linewidth':2}]*4

#plot(None, 'corr', po_corr, la_corr, li_corr, sh_corr, sc_corr, co_corr, da_corr, ma_corr)

panel2(
    [po_phase,po_corr], 
    [la_phase,la_corr], 
    [li_phase,li_corr], 
    [sh_phase,sh_corr], 
    [sc_phase,sc_corr], 
    [co_phase,co_corr], 
    [da_phase,da_corr], 
    [ma_phase,ma_corr])

plt.show()
