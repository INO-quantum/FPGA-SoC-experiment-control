#!/usr/local/bin/python3

import matplotlib as mpl
import matplotlib.pyplot as plt
import matplotlib.cm as cm
#from matplotlib.patches import Rectangle
import numpy as np
import re
from datetime import datetime
import io
import math
from os import listdir
import glob
from scipy.optimize import curve_fit

mpl.rcParams['font.family'] = 'DejaVu Sans'
plt.rcParams['font.size'] = 10
plt.rcParams['axes.linewidth'] = 2

#try to have a larger math text but does not work! 
#mpl.rcParams['mathtext.default']='regular'
#mpl.rcParams['mathtext.fontset']='dejavusans'

#import matplotlib.font_manager as fm# Collect all the font names available to matplotlib
#font_names = [f.name for f in fm.fontManager.ttflist]
#print(font_names)

colors = cm.get_cmap('tab20')
#colors = cm.get_cmap('tab20c')
#col=[colors(13),colors(0),colors(9),colors(5)]
#col=[colors(0),colors(4),colors(8)]

def get_float(txt):
    try:
        return float(txt)
    except Exception as e:
        if (len(txt) > 0): print('note: could not parse',txt,'as float')
        return np.NaN

def get_int(txt):
    try:
        return int(txt)
    except Exception as e:
        if (len(txt) > 0): print('note: could not parse',txt,'as integer')
        return np.NaN

# returns mask which is True where both x and y are not NaN
# apply mask as x[mask] and y[mask]
def mask_pair(x,y):
    return np.logical_and(~np.ma.getmask(np.ma.masked_invalid(x)), ~np.ma.getmask(np.ma.masked_invalid(y)))    
def mask_triple(x,y,err):
    return np.logical_and(~np.ma.getmask(np.ma.masked_invalid(x)), ~np.ma.getmask(np.ma.masked_invalid(y)), ~np.ma.getmask(np.ma.masked_invalid(err)))    
    
#returns string in the form value(error)
def str_error(value, error):
    try:
        pwr = np.log10(abs(error))
        #print(pwr)
        pwr = int(math.floor(pwr))
        #print(pwr)
        if pwr < 0: # pwr = digits after comma
            pwr = -pwr
            fmt = '%%.%if(%%i)' % (pwr)
            #print(fmt)
            txt = fmt % (round(value,pwr),int(round(abs(error)*10**pwr)))
        else: # pwr = digits before comma
            fmt = '%i(%i)'
            txt = fmt % (int(round(value/10**pwr))*10**pwr,int(round(abs(error)/10**pwr))*10**pwr)
        print('\t\tstr_error note: %f +/- %f = %s' % (value,error,txt))
        #print(txt)
    except:
        txt = "%f+/-%f" % (value,error);
    return txt

def read(filename, scaling=[1.0,1.0], cols=(0,1,2), check_err=True, rtn=2):
    "reads data from CSV file and returns [x,y] data where err == 0"
    cnv={0:get_int, 1:get_int, 2:get_int, 3:get_int, 4:get_int, 5:get_int, 6:get_int, 7:get_int, 8:get_int, 9:get_int, 10:get_int}
    with io.open(filename, 'rt', encoding='latin1') as file:
        x, y, err = np.loadtxt(file, unpack=True, delimiter=',', skiprows=0, usecols=cols, converters=cnv)
        x = x * scaling[0]
        y = y * scaling[1]
        mask = mask_triple(x,y,err)
        if check_err:
            if rtn == 3:
                return np.transpose([[xy[0],xy[1],xy[2]] for xy in np.transpose([x[mask],y[mask],err[mask]]) if xy[2] == 0])
            else:
                return np.transpose([[xy[0],xy[1]] for xy in np.transpose([x[mask],y[mask],err[mask]]) if xy[2] == 0])
        else:
            if rtn == 3: return [x[mask],y[mask],err[mask]]
            else: return [x[mask],y[mask]]
            
    return [[],[]]

def average(data):
    """
    calculates mean and standard deviation 
    data = [x,y]
    returns list of [x,mean_y,std_y] for each datapoint
    """
    x,indices = np.unique(data[0],return_inverse=True)
    return np.array([[xi,np.mean(data[1][indices==k]),np.std(data[1][indices==k])] for k,xi in enumerate(x)])

def plot(ax, panel, data, label, model, shade, scale, col, d_args, m_args):
    """
    generic plot of data for all panels
    data = list of data_i per channel with data_i = [data_x,data_y,data_error] with each entry 1d vectors, [] if not used
    label = 1d list of labels for each channel
    model = list of model_i curves for each channel with model_i = [model_x,model_y] with each entry 1d vector, model_i = None if not used
    shade = list of [shade_min_i,shade_max_i] for each channel where shade is drawn between min and max curves consisting of [x,y] with 1d vectors, [] if not used
    scale = 1d list of y-scaling factors for data_y and data_error, 1 = no scaling
    col = 1d list of colors for each channel
    d_args = 1d list of {arguments} for data plot
    m_args = 1d list of {arguments} for model plot
    """
    global colors, rate_mean, rate_std

    if ax == None: 
        fig = plt.figure(figsize=(7,7*3/4)) #size in inches
        ax = fig.add_axes([0.1, 0.1, 0.8, 0.8])
        is_panel = False
    else:
        is_panel = True
    #ax.set_title('2019 Cr oven resistance vs. temperature')

    xylabel_size    = 16 # axis x and y label fontsize
    tick_labelsize  = 12 # size of tick labels
    text_size       = 12 # size of all text
    legend_fontsize = 16 # size of legend text

    ax.xaxis.set_tick_params(which='major', size=10, width=2, direction='in', top='on'  , labelsize=tick_labelsize)
    ax.xaxis.set_tick_params(which='minor', size=7 , width=2, direction='in', top='on'  , labelsize=tick_labelsize)
    ax.yaxis.set_tick_params(which='major', size=10, width=2, direction='in', right='on', labelsize=tick_labelsize)
    ax.yaxis.set_tick_params(which='minor', size=7 , width=2, direction='in', right='on', labelsize=tick_labelsize)

    ax.set_ylabel(r'$\Gamma$ (MB/s)', labelpad=5, fontsize=xylabel_size)
    lim = [-50, 650]
    ticks = [0,100,200,300,400,500,600]
    ax.set_ylim(lim[0], lim[1])
    ax.set_yticks(ticks)
    pos=12*50
    ax.axhline(y=pos, color='k', linestyle='dotted', zorder=1)
    pos=rate_mean
    ax.axhline(y=pos, color='r', linestyle='dotted', zorder=1)
    #rate = str_error(rate_mean,rate_std)+' MB/s' # this gives 341.4(10) but we would like to have 341(1).
    rate = '%d(%d) MB/s'%(round(rate_mean),round(rate_std))
    ax.text(2.0, 0.97*pos, rate, fontsize=text_size, rotation=00, ha='left', va='top', color='r')
    ax2 = ax.twinx()
    ax2.set_ylabel(r"$f_{PL}\,t/N$ (PL cycles / sample)", labelpad=5, fontsize=xylabel_size)
    ax2.set_ylim(lim[0],lim[1])
    ticks = np.array([0,12*50,12*50/2,12*50/4,12*50/8,12*50/16])
    ax2.set_yticks(ticks)
    ax2.set_yticklabels([r'+$\mathdefault{\infty}$']+[str(int(12*50/t)) for t in ticks[1:]])
    ax2.yaxis.set_tick_params(which='major', size=10, width=2, direction='in', right='on')
    ax2.yaxis.set_tick_params(which='minor', size=7, width=2, direction='in', right='on')

    ax.set_xscale('log')
    ax.set_xlim(1, 2e7)
    ax.set_xlabel('N (samples)', labelpad=5, fontsize=xylabel_size)

    pos = 8192
    ax.axvline(x=pos, color='k', linestyle='dotted', zorder=1)
    ax.text(pos-250*pos/2000, 240, 'TX & RX FIFO', fontsize=text_size, rotation=90, ha='right', va='top')

    for i,d in enumerate(data):
        #shaded region between two curves
        if (len(shade[i]) > 0):
            x = shade[i][0][0]
            y0 = scale[i]*shade[i][0][1]
            y1 = scale[i]*shade[i][1][1]
            col_rgb=mpl.colors.to_hex(col[i])+"50" # add transparency: 0 = fully transparent, ff = opaque
            ax.fill_between(x, y0, y1, facecolor=col_rgb, interpolate=False) #'paleturquoise'
        #model curve
        if model[i] != None: #plot model if not None
            ax.plot(model[i][0], scale[i]*model[i][1], color=col[i], zorder=1, **m_args[i])
        if (len(d) > 0):
            if len(d) == 2: # get mean and std
                xy = np.transpose(average(d))
                print("note: get mean and std")
            else: # data already contains mean and std
                xy = d
            if scale[i] != 1: 
                print('*** ATTENTION: \'%s\' scaled x %f ***' % (label[i],scale[i]))
                xy[1] = xy[1]*scale[i]
                xy[2] = xy[2]*scale[i]
                #print(xy)
                #y=np.array(sorted(xy[1], key=lambda x: x[0]))
                y = np.transpose(xy)[np.array(xy[0]).argsort()]
                ax.text(y[-1][0], y[-1][1]+2, "x"+str(scale[i]), fontsize=legend_fontsize, rotation=0, ha='right', va='bottom', color=col[i])
            # plot error bars with scaling = sc
            sc = 1
            for j in range(len(xy[0])):
                ax.plot([xy[0][j],xy[0][j]], [xy[1][j]-sc*xy[2][j],xy[1][j]+sc*xy[2][j]], color=col[i], linestyle='solid', linewidth=2, zorder=1)
            # plot mean values
            ax.scatter(xy[0], xy[1], color=col[i], label=label[i], zorder=2, **d_args[i])

    ax.legend(bbox_to_anchor=(0.6, 0.13), loc='lower left', frameon=True, fontsize=legend_fontsize, ncol = 1, framealpha=1.0, edgecolor='black')

    plt.savefig('figure_4.pdf', dpi=300, transparent=False, bbox_inches='tight')
    
def rate2cycles(data):
    'convert rate in MB/s to cycle time'
    return [data[0],12*50*data[0]/data[1]]

def cycles2rate(data):
    'convert cycle time to rate in MB/s'
    if len(data) == 3: return [data[0],12*50*data[0]/data[1],12*50*data[2]*data[0]/(data[1]*data[1])] # [x,y,dy]
    else: return [data[0],12*50*data[0]/data[1]] # [x,y]

def delay_model(x, offset, rate, rate_2 = 0.0):
    'return number of cycles for given offset in cycles + data rate in MB/s for x = number of samples'
    return abs(offset) + 12*50*x/rate + x*x*rate_2

def delay_model_rate(x, offset, rate, rate_2 = 0.0):
    'return rate in MB/s for given offset in cycles + data rate in MB/s for x = number of samples'
    return 12*50*x/(abs(offset) + 12*50*x/rate + x*x*rate_2)

def two_rate_model(x, offset, rates, threshold):
    'return cycles for given offset in cycles + 2 data rates in MB/s with threshold in samples for x = number of samples'
    return offset + 12*50*np.array([threshold/rates[0]+(xi-threshold)/rates[1] if xi > threshold else xi/rates[0] for xi in x])

def fit_delay(dd, offset, rate, fit_model):
    global x
    '''
    fit data 
    fit parameter starting pars = [offset in cycles, rate in MB/s]
    fits in log scale if fit_log = True, othwerwise in linear scale
    fits additional quadratic delay if fit_2 = True (only log rate model)
    returns [fitted model,parameters,errors,chi^2 of [start,fit]]
    '''
    dx = dd[0]
    dy = dd[1]
    dy = 12*50*dx/dy
    chi2_start = np.sum(np.power(delay_model_rate(dx, offset, rate)-dy,2))
    par, cov = curve_fit((lambda x,o,r: delay_model_rate(x, o, r)), dx, dy, p0 = [offset,rate])     
    err = np.sqrt(np.diag(cov))
    chi2_fit = np.sum(np.power(delay_model_rate(dx, par[0], par[1])-dy,2))
    model = [x,delay_model(x, par[0], par[1])]
    return [model,par,err,[chi2_start,chi2_fit]]

def join(lists, remove_y = None):
    """join and sort n-D lists=[list,list,...] and remove entries with y=remove_y if not None"""
    #joined = [np.concatenate([l[0] for l in lists]),np.concatenate([l[1] for l in lists])]
    joined = [np.concatenate([l[i] for l in lists]) for i in range(len(lists[0]))]
    if remove_y == None: 
        return joined
    else:
        if len(joined) == 3: return np.transpose([xy for xy in sorted(np.transpose(joined), key=(lambda e: e[0])) if (xy[1] > 0) and (xy[2] > 0)])
        else: return np.transpose([xy for xy in sorted(np.transpose(joined), key=(lambda e: e[0])) if xy[1] > 0])


#x-values for model plots
x = np.array([2**i for i in np.arange(1,23,0.1)] + [1.2e7]) # samples in powers of 2

#files contain 12 columns:
#[set #,TX #,time,RX #,RX time,RX data,TX IRQs,RX IRQs,FPGA IRQs,CPU0,CPU1,err]

#folder with data
folder_c10 = 'data/Cora-Z7-10/'

##########################################################################################################
# TX data
##########################################################################################################

if False: # TX only
    c10_TX = read(folder_c10+'20201111_c10_TX.csv',[1.0,1.0],(1,2,11),False,2)
else: # TX with RX active
    c10_TX = np.transpose(average(read(folder_c10+'20201111_c10_TX_plus.csv',[1.0,1.0],(1,2,11),False,2)))

# estimate rate above threshold samples
threshold = 1000
avg_TX = np.mean([y[0]*12*50/y[1] for y in np.transpose(c10_TX) if y[0]>=threshold])
std_TX = np.std([y[0]*12*50/y[1] for y in np.transpose(c10_TX) if y[0]>=threshold])
#print('TX rate = %s MB/s (average @ # >= %i)' %(str_error(avg_TX,std_TX),threshold))

#model time with rate[0] below threshold and rate[1] above threshold. only free parameter is rate above threshold 
rate = [600,avg_TX] # rate [below,above] threshold
threshold = 4
offset = 0
time = two_rate_model(x, offset, rate, threshold) 
par, cov = curve_fit(lambda x,r: two_rate_model(x, offset, [rate[0], r], threshold), c10_TX[0], c10_TX[1], p0 = [rate[1]]) 
err = np.sqrt(np.diag(cov))
model_TX = [x,two_rate_model(x, offset, [rate[0], par[0]], threshold)]
print('TX rate = %s MB/s (fit result)' %(str_error(par[0],err[0])))
avg_TX = par[0];
std_TX = err[0];

##########################################################################################################
# RX data
##########################################################################################################

c10_RX = np.transpose(average(join([
    read(folder_c10+'20201111_c10_RX.csv',[1.0,1.0],(1,2,11),False,2),
    read(folder_c10+'20201111_c10_RX_2.csv',[1.0,1.0],(1,2,11),False,2),
    read(folder_c10+'20201111_c10_RX_3.csv',[1.0,1.0],(1,2,11),False,2)], remove_y=0)))

#estimate offset from below threshold samples
threshold = 100
avg_RX = np.mean([y[1] for y in np.transpose(c10_RX) if y[0]<=threshold])
std_RX = np.std([y[1] for y in np.transpose(c10_RX) if y[0]<=threshold])
#print('RX delay = %s cycles = %s us (average @ # <= %i)' %(str_error(avg_RX,std_RX),str_error(avg_RX*20e-3,std_RX*20e-3),threshold))

#model time with constant offset + samples/rate. free parameter = offset and rate
rate = avg_TX # MB/s
offset = avg_RX # constant offset
time = delay_model(x, offset, rate) # total cycles
data = np.array(c10_RX)
model_RX, par, err, chi2 = fit_delay(data, offset, rate, 'cycles/sample')
print('RX delay = %s cycles = %s us (fit result)' %(str_error(par[0],err[0]),str_error(par[0]*20e-3,err[0]*20e-3)))
print('RX rate  = %s MB/s (fit result)' %(str_error(par[1],err[1])))
#print('RX chi^2 = %e (start) -> %e (fit)' % (chi2[0], chi2[1]))
avg_RX = par[1]
std_RX = err[1]

##########################################################################################################
# RX write data
##########################################################################################################

# taken together with RX data
c10_RX_write = np.transpose(average(join([
    read(folder_c10+'20201111_c10_RX.csv',[1.0,1.0],(3,4,11),False,2),
    read(folder_c10+'20201111_c10_RX_2.csv',[1.0,1.0],(3,4,11),False,2),
    read(folder_c10+'20201111_c10_RX_3.csv',[1.0,1.0],(3,4,11),False,3)], remove_y=0)))

# fit RX write
data = c10_RX_write
rate = [600,avg_TX] # rate [below,above] threshold
threshold = 2e4
offset = 0
par, cov = curve_fit(lambda x,r,th: two_rate_model(x, offset, [rate[0], r], th), data[0], data[1], p0 = [rate[1],threshold]) 
err = np.sqrt(np.diag(cov))
model_RX_write = [x,two_rate_model(x, offset, [rate[0], par[0]], par[1])]
print('RX write rate = %s MB/s (fit result)' %(str_error(par[0],err[0])))
print('RX threshold = %s cycles (fit result)' %(str_error(par[1],err[1])))
avg_RX_FIFO = par[0]
std_RX_FIFO = err[0]

rate_mean = np.mean([avg_TX,avg_RX,avg_RX_FIFO])
rate_std  = np.std ([avg_TX,avg_RX,avg_RX_FIFO])
print('average DMA rate = %s' % str_error(rate_mean,rate_std))

##########################################################################################################
# plot figure with DMA rates
##########################################################################################################

data_b1  = [cycles2rate(c10_TX), cycles2rate(c10_RX), cycles2rate(c10_RX_write)]
label_b1 = ['TX DMA','RX DMA','RX FIFO']
model_b1 = [cycles2rate(model_TX),cycles2rate(model_RX),cycles2rate(model_RX_write)]
shade_b1 = [[]]*3 
scale_b1 = [1,1,1,1,1,1,1,1,1,1]
col_b1   = [colors(6),colors(2),colors(4),colors(18)]
d_args_b1 = [{'s':80,'marker':'o','facecolors':'white'},{'s':50,'marker':'s','facecolors':'white'},{'s':50,'marker':'D','facecolors':'white'}]
m_args_b1 = [{'linestyle':'solid', 'linewidth':2}]*3

plot(None, 'DMA', data_b1, label_b1, model_b1, shade_b1, scale_b1, col_b1, d_args_b1, m_args_b1)

plt.show()
