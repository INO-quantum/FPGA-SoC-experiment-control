#!/usr/local/bin/python3

import matplotlib as mpl
import matplotlib.pyplot as plt
import matplotlib.cm as cm
#from matplotlib.patches import Rectangle
import numpy as np
import re
from datetime import datetime
import io
import math
from os import listdir
import glob
from scipy.optimize import curve_fit

mpl.rcParams['font.family'] = 'DejaVu Sans'
plt.rcParams['font.size'] = 10
plt.rcParams['axes.linewidth'] = 2

#try to have a larger math text but does not work! 
#mpl.rcParams['mathtext.default']='regular'
#mpl.rcParams['mathtext.fontset']='dejavusans'

#import matplotlib.font_manager as fm# Collect all the font names available to matplotlib
#font_names = [f.name for f in fm.fontManager.ttflist]
#print(font_names)

colors = cm.get_cmap('tab20')
#colors = cm.get_cmap('tab20c')
#col=[colors(13),colors(0),colors(9),colors(5)]
#col=[colors(0),colors(4),colors(8)]

def get_float(txt):
    try:
        return float(txt)
    except Exception as e:
        if (len(txt) > 0): print('note: could not parse',txt,'as float')
        return np.NaN

def get_int(txt):
    try:
        return int(txt)
    except Exception as e:
        if (len(txt) > 0): print('note: could not parse',txt,'as integer')
        return np.NaN

# returns mask which is True where both x and y are not NaN
# apply mask as x[mask] and y[mask]
def mask_pair(x,y):
    return np.logical_and(~np.ma.getmask(np.ma.masked_invalid(x)), ~np.ma.getmask(np.ma.masked_invalid(y)))    
def mask_triple(x,y,err):
    return np.logical_and(~np.ma.getmask(np.ma.masked_invalid(x)), ~np.ma.getmask(np.ma.masked_invalid(y)), ~np.ma.getmask(np.ma.masked_invalid(err)))    
    
#returns string in the form value(error)
def str_error(value, error):
    try:
        pwr = np.log10(abs(error))
        #print(pwr)
        pwr = int(math.floor(pwr))
        #print(pwr)
        if pwr < 0: # pwr = digits after comma
            pwr = -pwr
            fmt = '%%.%if(%%i)' % (pwr)
            #print(fmt)
            txt = fmt % (round(value,pwr),int(round(abs(error)*10**pwr)))
        else: # pwr = digits before comma
            fmt = '%i(%i)'
            txt = fmt % (int(round(value/10**pwr))*10**pwr,int(round(abs(error)/10**pwr))*10**pwr)
        print('\t\tstr_error note: %f +/- %f = %s' % (value,error,txt))
        #print(txt)
    except:
        txt = "%f+/-%f" % (value,error);
    return txt

def read(filename, cols=(0,1), scaling=[1,1], skip=0):
    "reads data from CSV file and returns [x,y,..] data"
    cnv={0:get_float, 1:get_float, 2:get_float, 3:get_float, 4:get_float, 5:get_float}
    with io.open(filename, 'rt', encoding='latin1') as file:
        data = np.loadtxt(file, unpack=True, delimiter=',', skiprows=skip, usecols=cols, converters=cnv)
        data = [data[i]*sc for i,sc in enumerate(scaling)]
        return data
    return [[] for _ in cols]

def average(data):
    """
    calculates mean and standard deviation 
    data = [x,y]
    returns list of [x,mean_y,std_y] for each datapoint
    """
    x,indices = np.unique(data[0],return_inverse=True)
    return np.array([[xi,np.mean(data[1][indices==k]),np.std(data[1][indices==k])] for k,xi in enumerate(x)])

def plot(ax, panel, data, label, model, shade, scale, col, d_args, m_args):
    """
    generic plot of data for all panels
    data = list of data_i per channel with data_i = [data_x,data_y,data_error] with each entry 1d vectors, [] if not used
    label = 1d list of labels for each channel
    model = list of model_i curves for each channel with model_i = [model_x,model_y] with each entry 1d vector, model_i = None if not used
    shade = list of [shade_min_i,shade_max_i] for each channel where shade is drawn between min and max curves consisting of [x,y] with 1d vectors, [] if not used
    scale = 1d list of y-scaling factors for data_y and data_error, 1 = no scaling
    col = 1d list of colors for each channel
    d_args = 1d list of {arguments} for data plot
    m_args = 1d list of {arguments} for model plot
    """
    #global avg_TX, std_TX, colors

    if ax == None: 
        fig = plt.figure(figsize=(7,7*3/4)) #size in inches
        ax = fig.add_axes([0.1, 0.1, 0.8, 0.8])
        is_panel = False
    else:
        is_panel = True
    #ax.set_title(r'sender + 10m + receiver + 10m + T open/50$\Omega$/short + 10m + 50$\Omega$')

    xylabel_size    = 16 # axis x and y label fontsize
    tick_labelsize  = 12 # size of tick labels
    text_size       = 12 # size of all text
    legend_fontsize = 16 # size of legend text

    ax.xaxis.set_tick_params(which='major', size=10, width=2, direction='in', top='on'  , labelsize=tick_labelsize)
    ax.xaxis.set_tick_params(which='minor', size=7 , width=2, direction='in', top='on'  , labelsize=tick_labelsize)
    ax.yaxis.set_tick_params(which='major', size=10, width=2, direction='in', right='on', labelsize=tick_labelsize)
    ax.yaxis.set_tick_params(which='minor', size=7 , width=2, direction='in', right='on', labelsize=tick_labelsize)

    if panel == 'a':
        if is_panel: 
            ax.set_xticklabels(['']*len(ax.get_xticklabels()))
        else:
            ax.set_xlabel('time (ns)', labelpad=5, fontsize=xylabel_size)
        ax.set_ylabel('signal (V)', labelpad=17, fontsize=xylabel_size)
        ax.set_xlim(-50, 250)
        ax.set_ylim(-1, 6)
        ax.set_yticks([0,2,4])
    else:
        if not is_panel: 
            ax.set_title('10m cable')
        ax.set_xlabel('time (ns)', labelpad=5, fontsize=xylabel_size)
        ax.set_xlim(-50, 250)
        ax.set_ylabel('phase (degree)', labelpad=2, fontsize=xylabel_size)
        ax.set_ylim(-50, 410)
        ax.set_yticks([0,90,180,270,360])

    for i,d in enumerate(data):
        #shaded region between two curves
        if (len(shade[i]) > 0):
            x = shade[i][0][0]
            y0 = scale[i]*shade[i][0][1]
            y1 = scale[i]*shade[i][1][1]
            col_rgb=mpl.colors.to_hex(col[i])+"50" # add transparency: 0 = fully transparent, ff = opaque
            ax.fill_between(x, y0, y1, facecolor=col_rgb, interpolate=False) #'paleturquoise'
        #model curve
        if len(model[i]) != 0: #plot model if not None
            if (len(d) == 0):
                ax.plot(model[i][0], scale[i]*model[i][1], color=col[i], label=label[i], **m_args[i])
            else:
                ax.plot(model[i][0], scale[i]*model[i][1], color=col[i], **m_args[i])
        if (len(d) > 0):
            if len(d) == 2: # get mean and std
                xy = np.transpose(average(d))
                print("note: get mean and std")
            else: # data already contains mean and std
                xy = d
            if scale[i] != 1: 
                print('*** ATTENTION: %s scaled x %i ***' % (label[i],scale[i]))
                xy[1] = xy[1]*scale[i]
                xy[2] = xy[2]*scale[i]
                y=np.array(sorted(xy[1], key=lambda x: x[0]))
                ax.text(y[-1][0], y[-1][1]+30, "x"+str(scale[i]), fontsize=legend_fontsize, rotation=0, ha='right', va='bottom', color=col[i])
            # plot error bars with scaling = sc
            sc = 1
            for j in range(len(xy[0])):
                ax.plot([xy[0][j],xy[0][j]], [xy[1][j]-sc*xy[2][j],xy[1][j]+sc*xy[2][j]], color=col[i], linestyle='solid', linewidth=2)
            # plot mean values
            ax.scatter(xy[0], xy[1], color=col[i], label=label[i], **d_args[i])

    if panel == 'a': # upper panel
        ax.legend(bbox_to_anchor=(0.05, 1.07), loc='upper left', frameon=True, fontsize=legend_fontsize, ncol=4, framealpha=1.0, edgecolor='black')

    #plt.savefig('panel_'+panel+'.png', dpi=300, transparent=False, bbox_inches='tight')
    
def panel(data, label, model, shade, scale, col, d_args, m_args):

    fig = plt.figure(figsize=(7,7*3/4)) #size in inches

    #panels from top to bottom
    panels = ['a','b']
    labels = ['a','b']
    width = 0.8
    height = [0.30,0.50]
    left = 0.1
    bottom = 0.1

    ax = [None for p in panels]
    for i,p in enumerate(panels):
        y_top = bottom + sum(height[i:]) # y top coordinate of panel
        ax[i] = fig.add_axes([left, y_top-height[i], width, height[i]])
        plot(ax[i], p, data[i], label[i], model[i], shade[i], scale[i], col[i], d_args[i], m_args[i])
        plt.text(0.015,y_top,labels[i],fontsize=16,transform=fig.transFigure,verticalalignment='top')

    #ax[0].set_title(r'sender + 10m + receiver high Z + 10m + 50$\Omega$/open/short')

    plt.savefig('figure_9.pdf', dpi=300, transparent=False, bbox_inches='tight')


deg_cal=1120        # steps for 360 degrees
xoff = 20.0/12.0    # x offset
yoff = 12.0         # y offset

##########################################################################################################
# panel (a) detector signal at 10m cable length
##########################################################################################################

dir = '20210119_auto_sync/'
#ch1 = pulse from FPGA, ch3 = sync_en = received & decoded signal, ch3 = coax pulse on receiver, ch4 = coax pulse on sender
#[x,y,err], we set err = 0, if no error is given will be calculated which we do not want now
data = read(dir+'osci_10m_2/SDS00001.csv',(0,1,2,3,4),[1e9,10,10,10,10],skip=2)
shift = -10
ch10 = [data[0]+shift,data[1],[0 for _ in data[0]]]
ch20 = [data[0]+shift,data[2],[0 for _ in data[0]]]
ch30 = [data[0]+shift,data[3],[0 for _ in data[0]]]
ch40 = [data[0]+shift,data[4],[0 for _ in data[0]]]

data_a  = [[]]*3
label_a = ['detector','prim','sec']
model_a = [ch20,ch40,ch30]
shade_a = [[]]*3
scale_a = [1]*3
col_a   = [colors(4),colors(8),colors(18),'royalblue',colors(6)]
d_args_a = [{'s':50}]*3
m_args_a = [{'linestyle':'solid', 'linewidth':2}]*3

##########################################################################################################
# panel (b) osci signal at 10m cable length
##########################################################################################################

dir = '20210120_auto_sync/'

file_1=range(3,59,1)
num_1=len(file_1)
phase_1=np.array([0,40,80,121,161,202,242,280,320,360,401,441,482,482,479,479,476,476,472,472,469,485,485,488,488,491,494,494,497,497,500,500,504,507,507,510,
                519,560,600,640,681,721,762,799,799,765,768,771,840,880,920,961,1001,1039,1079,1120])
time_1=np.array([7,7,7,7,7,7,7,7,7,7,7,7,8,7,7,8,7,8,8,7,7,7,8,7,8,7,7,8,8,8,8,7,8,7,8,8,8,8,8,8,8,8,8,7,8,8,8,8,7,7,7,7,7,7,7,7])

if True: # select phase at equal spacings
    step = 40;
    sel = [np.arange(len(phase_1))[abs(phase_1-s) <= 2][0] for s in np.arange(0,1120+step,step)]
    phase_1 = phase_1[sel]
    time_1 = time_1[sel]
    file_1 = np.array(file_1)[sel]
    num_1 = len(file_1)
phase_1 = phase_1*360.0/deg_cal;
ph_data_1 = [read(dir+'data1/SDS%05d.csv' % (file_1[i]),(0,2),[1e9,10],skip=2) for i,ph in enumerate(phase_1)]
ph_jump = 125
ph_data_1 = [[d[0],d[1]*yoff/3.3+phase_1[i]-yoff] if phase_1[i] < ph_jump else [d[0]+20,d[1]*yoff/3.3+phase_1[i]-yoff] for i,d in enumerate(ph_data_1)]
time_1=np.transpose([time_1*20,phase_1])
time_1=np.transpose(time_1[time_1[:,1].argsort()]) # sort by phase

#time relative to fast clock (=detection clock) when pulse is generated
pulse = [[-22+ph*20/360 for ph in range(0,365,5)],[ph for ph in range(0,365,5)]]
#estimated time from start signal (@ fast clock) until detection of generated pulse falling edge (@ fast clock)
ph_jump = 280
t0 = [[180+((ph+360-ph_jump)//360)*20 for ph in range(0,365,5)],[ph for ph in range(0,365,5)]]
#from time_1 calculated time from start signal (@ fast clock) until detection of reflected pulse rising edge (@ fast clock)
ph_jump = 150
t1 = [[200+((ph+360-ph_jump)//360)*20 for ph in range(0,365,5)],[ph for ph in range(0,365,5)]]

data_b  = [[] for _ in range(num_1+3)]
label_b = ['detector']+[None]*(num_1-1)+['pulse','t0','t1']
model_b = ph_data_1+[pulse,t0,t1]
shade_b = [[] for _ in range(num_1+3)] 
scale_b = [1 for _ in range(num_1+3)]
col_b = [colors(4) for _ in range(num_1)] + [colors(2),'royalblue',colors(6),'blue','red']
d_args_b = [{'s':50} for _ in range(num_1+3)]
m_args_b = [{'linestyle':'solid', 'linewidth':2}]*num_1 + [{'linestyle':'solid', 'linewidth':2}]*3

ph_jump = 50
t0 = [[160+((ph+360-ph_jump)//360)*20 for ph in range(0,365,5)],[ph for ph in range(0,365,5)]]
ph_jump = 140
t1 = [[160+((ph+360-ph_jump)//360)*20 for ph in range(0,365,5)],[ph for ph in range(0,365,5)]]

panel([data_a,data_b], 
    [label_a,label_b], 
    [model_a,model_b], 
    [shade_a,shade_b], 
    [scale_a,scale_b], 
    [col_a,col_b], 
    [d_args_a, d_args_b], 
    [m_args_a, m_args_b])

plt.show()
